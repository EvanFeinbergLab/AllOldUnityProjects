﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class MasterCtrl : MonoBehaviour
{
    public enum GameVersion {BilateralCorridorTraining,
                             AlternateBilateralStim,
                             LowContrastDetection,
                            CuedLowContrastDetection};

    public GameVersion GameMode;
    public bool SmallStim;
    public bool BilateralStim;
    public bool Cued;
    public bool AlternateNoCue; 

    public string StimVersion; 

    public float StimPresentationTime;
    public float CuePresentTime; 
    public float CueStimGap; 
    public float StimOffset;

    private string lastReceivedUDPPacket = "";
    public string lastSentUDPPacket = "";

    public int StimTrialCount;
    public int VertTrialCount;
    public float RelativePosition;
    public float StimDistance;
    private float NextDot; 
    public float fps; 

    private Vector3 GroundCoord;
    private Vector3 CeilingCoord;
    private Vector3 VertGreyRWCoord;
    private Vector3 VertGreyLWCoord;
    private Vector3 NewPosition;
    private Vector3 LeftVertDefault;
    private Vector3 RightVertDefault;
    private Vector3 LeftVertGratingDisplaced;
    private Vector3 RightVertGratingDisplaced;

    private Vector3 Location;
    private float RandStim;
    private int RandStimVersion;

    UdpClient client;
    UdpClient SendClient;
    private Thread receiveThread;
    private Thread sendThread;

    private bool receiveRunning;
    private bool sendRunning;
    private bool Reset;
    private bool RandReceived;
    private bool PositionReached;
    private bool VertCloneAppeared;
    private bool VStimTriggered;
    private bool StimStarted;
    private bool RandCreated;
    private bool CueShown;
    private bool Move;
    private bool TimerStarted;
    private bool StimMoved;
    private bool Small;
    private bool Panel;
    private bool CueStarted;
    private bool ContrastSet; 

    private bool MoveVStim;
    private bool VariantVersion; 

    private int ResetSesh;
    private int StimReceived;
    private int stringSize;
    private int resetPos;
    private int RandDist;

    private int FwdInstanNum;
    private int RevInstanNum;
    private int InstanLength;
    private int origin;

    private int revNum; 

    private int SendPort;
    private int ReceivePort;
    private byte[] data;
    private byte[] DataToSend;

    public int ContrastVersion;
    private string ContrastLevel;

    public int[] FakeCueDist;
    private float NumFlashes;
    private int Flashes;
    private int DistFrac;
    private float RandSide;
    private float OldPosition;
    private int DotDist;
    private float LastDist;
    private int ItA;
    private bool FakeCueStarted;
    private float FakeCueTimer;
    private float FakeCueX;
    private string FA;
    private int FalseAlarm;
    public bool DistPunish;
    private int FlashSide;
    private float CueOrNot;
    public bool NoCue;
    private bool CueOrNotCreated;
    private float RandCueSide;
    private int PossiblePunish;
    private float TotalPossibleDist; 

    private string text;
    private string TextToSend;
    private string PosIn;
    private string RandNum;
    private string StimTrig;
    private string NewTrial;
    private string itString;
    private string RWCloneName;
    private string LWCloneName;
    private string ReceivedStim;
    private string ResetSession;
    private string StimVariant; 

    private string CloneNum;
    private string udpIn;
    private string udpOut;
    private string LCloneName;
    private string RCloneName;
    private string FWallCloneNum;
    private string BWallCloneNum;
    private string StimWindow;
    private string Task;
    private string SendIP;   
    private string LVMessage; 

    private float DiagRandZ;
    private float LastPosition;
    private float deltaTime;
    public float StimTimer; 
     public float CueTimer; 

    private float RCamDistance; //cam location
    private float LCamDistance;
    private float position; //UDP position
    private float smoothing;
    private float fracMovt;
    private float CorridorLocation;
    private float CamX;

    private float PrevRandDist;
    private float offset;
    private float CueOffset;
    private float RandDot;
    private float RightCueX;
    private float LeftCueX;
    private float CurrLeftCueX;
    private float CurrRightCueX;

    private float VertRandY;
    private float VRandY;
    private float VertRandDot;

    private GameObject VRBDotClone;
    private GameObject VLBDotClone;
    private GameObject VRWDotClone;
    private GameObject VLWDotClone;
    private GameObject VShuffleRDot;
    private GameObject VShuffleLDot;
    private GameObject WhiteDotClone;
    private GameObject BlackDotClone;

    private GameObject VCeilingClone;
    private GameObject RevVCeilingClone;
    private GameObject VGrndClone;
    private GameObject RevVGrndClone;
    private GameObject VRWClone;
    private GameObject VLWClone;

    public GameObject LeftVertGrating;
    public GameObject RightVertGrating;
    public GameObject LeftCue;
    public GameObject RightCue;
    public GameObject FakeCue;

    public GameObject FullContrastR;
    public GameObject LowContrast1R;
    public GameObject LowContrast2R;
    public GameObject LowContrast3R;
    public GameObject LowContrast4R;
    public GameObject LowContrast5R;
    public GameObject LowContrast6R;
    public GameObject FullContrastL;
    public GameObject LowContrast1L;
    public GameObject LowContrast2L;
    public GameObject LowContrast3L;
    public GameObject LowContrast4L;
    public GameObject LowContrast5L;
    public GameObject LowContrast6L;
    //public GameObject LowContrast7 ;

    private GameObject LeftSmallVert;
    private GameObject RightSmallVert;

    public GameObject LeftEye;
    public GameObject RightEye;
    public GameObject VertCeiling;
    public GameObject VertGreyRW;
    public GameObject VertGreyLW;
    public GameObject VertGround;
    public GameObject WhiteDot;
    public GameObject BlackDot; 

    public Material Black;
    public Material LightGrey;
    public Material White;


    void Awake()
    {

        VertGreyRWCoord = VertGreyRW.transform.position;
        VertGreyLWCoord = VertGreyLW.transform.position;
        LeftVertGratingDisplaced = new Vector3(-50.0f, 2.5f, 7.5f);
        RightVertGratingDisplaced = new Vector3(50.0f, 2.5f, 7.5f);


        for (int i = 1; i < 11; i++)
        { 
            GameObject VCeilingClone = Instantiate(VertCeiling) as GameObject;
            VCeilingClone.transform.position = new Vector3(0.0f, 5.0f, i * 50.0f + 25f);          

            GameObject VLWClone = Instantiate(VertGreyLW) as GameObject;
            GameObject VRWClone = Instantiate(VertGreyRW) as GameObject;

            VLWClone.transform.position = new Vector3(VertGreyLWCoord.x, VertGreyLWCoord.y, i * 50.0f + VertGreyLWCoord.z);
            VRWClone.transform.position = new Vector3(VertGreyRWCoord.x, VertGreyRWCoord.y, i * 50.0f + VertGreyRWCoord.z);

            GameObject VGrndClone = Instantiate(VertGround) as GameObject;
            VGrndClone.transform.position = new Vector3(0.0f, -2.0f, i * 100.0f + 10f);
        }

        for (int i = 1; i < 4; i++)
        {
            GameObject RevVCeilingClone = Instantiate(VertCeiling) as GameObject;
            RevVCeilingClone.transform.position = new Vector3(0.0f, 5.0f, i * -50.0f + 25f);

            GameObject RevVGrndClone = Instantiate(VertGround) as GameObject;
            RevVGrndClone.transform.position = new Vector3(0.0f, -2.0f, i * -100.0f + 10f);

            GameObject RevVLWClone = Instantiate(VertGreyLW) as GameObject;
            GameObject RevVRWClone = Instantiate(VertGreyRW) as GameObject;

            RevVLWClone.transform.position = new Vector3(VertGreyLWCoord.x, VertGreyLWCoord.y, i * -50.0f + VertGreyLWCoord.z);
            RevVRWClone.transform.position = new Vector3(VertGreyRWCoord.x, VertGreyRWCoord.y, i * -50.0f + VertGreyRWCoord.z);

        }

        if (GameMode == GameVersion.BilateralCorridorTraining)

        {         
            LeftVertGrating.transform.position = new Vector3(-5.0f, 2.5f, 7.5f);
            RightVertGrating.transform.position = new Vector3(5.0f, 2.5f, 7.5f);

            LeftVertDefault = LeftVertGrating.transform.position;
            RightVertDefault = RightVertGrating.transform.position;

            for (int i = 1; i < 250; i++)
            {
                VertRandY = UnityEngine.Random.Range(0.0f, 4.0f);
                VertRandDot = UnityEngine.Random.value;

                if (VertRandDot < 0.5f)
                {
                    GameObject VRWDotClone = Instantiate(WhiteDot) as GameObject;
                    GameObject VLWDotClone = Instantiate(WhiteDot) as GameObject;

                    VRWDotClone.transform.position = new Vector3(-4.98f, VertRandY, i * 2 + 80);
                    VLWDotClone.transform.position = new Vector3(4.98f, VertRandY, i * 2 + 80);
                }

                if (VertRandDot > 0.5f)
                {
                    GameObject VRBDotClone = Instantiate(BlackDot) as GameObject;
                    GameObject VLBDotClone = Instantiate(BlackDot) as GameObject;

                    VRBDotClone.transform.position = new Vector3(-4.98f, VertRandY, i * 2 + 80);
                    VLBDotClone.transform.position = new Vector3(4.98f, VertRandY, i * 2 + 80);
                }
            }
        }

        else if (GameMode == GameVersion.AlternateBilateralStim)
        {

            LeftVertGrating.transform.position = new Vector3(-5.0f, 2.5f, 7.5f);
            RightVertGrating.transform.position = new Vector3(5.0f, 2.5f, 7.5f);

            LeftVertDefault = LeftVertGrating.transform.position;
            RightVertDefault = RightVertGrating.transform.position;
        }

        if(GameMode == GameVersion.LowContrastDetection || GameMode == GameVersion.CuedLowContrastDetection)
        {
            SmallStim = true;
            LeftVertGrating.transform.position = LeftVertGratingDisplaced;
            RightVertGrating.transform.position = RightVertGratingDisplaced;

        }
        

        offset = 15.0f;
        RandReceived = false;
        PrevRandDist = 0;
        TextToSend = "0OO";
        StimTrialCount = 0;
        RelativePosition = 0;
        StimTimer = 0;
    }       

    void Start()
    {
        Debug.Log("displays connected:" + Display.displays.Length);

        init();
        Application.runInBackground = true;

        if (SmallStim == true)
        {
            Small = true; 
        }

        OldPosition = 0;

        if(GameMode == GameVersion.CuedLowContrastDetection)
        {
            Cued = true; 
        }

        CueOffset = StimOffset;
        LeftCueX = LeftCue.transform.position.x;
        RightCueX = RightCue.transform.position.x;

    }

    public void Activate()
    {
        Screen.fullScreen = true;
    }

    private void init()
    {
        print("UDP.init()");

        ReceivePort = 8888;
        SendPort = 8051;
        SendIP = "169.230.68.193";

        receiveRunning = true;
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();

        sendRunning = true;
        sendThread = new Thread(new ThreadStart(SendData));
        sendThread.IsBackground = true;
        sendThread.Start();
    }


    void Update()
    {
        deltaTime += (Time.deltaTime - deltaTime) * 0.1f;
        fps = 1.0f / deltaTime;

        TextToSend = "0OO";

        udpIn = lastReceivedUDPPacket;
        stringSize = udpIn.Length;

        if (stringSize > 0)
        {
            ReceivedStim = udpIn.Substring(0, 1);
            ResetSession = udpIn.Substring(1, 1);
            StimVariant = udpIn.Substring(2, 1);
            ContrastLevel = udpIn.Substring(3, 1);
            RandNum = udpIn.Substring(4, 3);   
            FA = udpIn.Substring(7, 1);
            PosIn = udpIn.Substring(8, (stringSize - 8));
        }

        int.TryParse(ReceivedStim, out StimReceived);
        int.TryParse(ResetSession, out ResetSesh);
        int.TryParse(StimVariant, out RandStimVersion);
        int.TryParse(ContrastLevel, out ContrastVersion);
        int.TryParse(RandNum, out RandDist);
        int.TryParse(FA, out FalseAlarm);
        float.TryParse(PosIn, out position);      

        RelativePosition = position - LastPosition;
        RCamDistance = RightEye.transform.position.z;
        LCamDistance = LeftEye.transform.position.z;
        StimDistance = ((float)RandDist);

        if (FalseAlarm == 1)
        {
            DistPunish = true;
        }

        if (DistPunish == true)
        {
            StimDistance = StimDistance + 50.0f;
        }


        if (GameMode == GameVersion.AlternateBilateralStim || GameMode == GameVersion.LowContrastDetection || GameMode == GameVersion.CuedLowContrastDetection)          
        {
                if (ContrastVersion == 0)
                {
                    RightSmallVert = FullContrastR;
                    LeftSmallVert = FullContrastL;
                }

                if (ContrastVersion == 1)
                {
                    RightSmallVert = LowContrast1R;
                    LeftSmallVert = LowContrast1L;
                }

                if (ContrastVersion == 2)
                {
                    RightSmallVert = LowContrast2R;
                    LeftSmallVert = LowContrast2L;
                }

                if (ContrastVersion == 3)
                {
                    RightSmallVert = LowContrast3R;
                    LeftSmallVert = LowContrast3L;

                }

                if (ContrastVersion == 4)
                {
                    RightSmallVert = LowContrast4R;
                    LeftSmallVert = LowContrast4L;
                }

                if (ContrastVersion == 5)
                {
                    RightSmallVert = LowContrast5R;
                    LeftSmallVert = LowContrast5L;
                }

                if (ContrastVersion == 6)
                {
                    RightSmallVert = LowContrast6R;
                    LeftSmallVert = LowContrast6L;
                }
        }



            if (StimDistance != OldPosition && GameMode == GameVersion.CuedLowContrastDetection)
        {
            NumFlashes = UnityEngine.Random.Range(24.0f, 27.0f);
            Flashes = Convert.ToInt32(NumFlashes);
            PossiblePunish = Convert.ToInt32(StimDistance / 21.0f);
            TotalPossibleDist = PossiblePunish * 50 + StimDistance;
            DistFrac = Convert.ToInt32(TotalPossibleDist / Flashes);
            FakeCueDist = new int[Flashes];
            OldPosition = StimDistance;
            LastDist = StimDistance;

            for (int i = 1; i < Flashes + 1; i++)
            {
                NextDot = DistFrac * i;
                DotDist = Convert.ToInt32(UnityEngine.Random.Range(DistFrac * (i - 1), NextDot));

                if (DotDist < 10)
                {
                    DotDist = DotDist + 10;
                }

                if (StimDistance - DotDist < 40)
                {
                    DotDist = DotDist - 40;
                }

                if (i > 1)
                {
                    if (DotDist - LastDist < 10)
                    {
                        DotDist = DotDist + 10;
                    }
                }


                FakeCueDist[i - 1] = DotDist;
                if(DotDist - LastDist < 10)
                {
                    DotDist = DotDist + 10; 
                }

                LastDist = DotDist;
            }

            ItA = 1;

        }

        if (RelativePosition > FakeCueDist[ItA] && ItA < (Flashes - 1) && FakeCueDist[ItA] > 40 && Cued == true)
        {
            RandSide = UnityEngine.Random.value;
                if (RandSide < 0.5)
                {
                    FakeCueX = -4.98f;
                    FlashSide = 2;
                }

                if (RandSide >= 0.5)
                {
                    FakeCueX = 4.98f;
                    FlashSide = 1;
                }

            FakeCue.transform.position = new Vector3(FakeCueX, 2.5f, FakeCueDist[ItA] + CueOffset);
            FakeCueStarted = true;
            ItA = ItA + 1;

            if (ItA == Flashes)
            {
                ItA = 0;
            }
        }

        if (FakeCueDist[ItA] < 40)
        {
            ItA = ItA + 1;
        }

        if (FakeCueStarted == true)
        {
            FakeCueTimer += Time.deltaTime;
        }

        if (FakeCueTimer > CuePresentTime)
        {
            FakeCue.transform.position = new Vector3(-10.0f, 0.5f, 0.0f);
        }

        if (FakeCueTimer > CuePresentTime + 0.5f)
        {
            FakeCueTimer = 0;
            FakeCueStarted = false;
            FlashSide = 0;
        }

        //Cam Movement 
        if (position != LCamDistance)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, RelativePosition);
            RightEye.transform.position = new Vector3(transform.position.x, transform.position.y, RelativePosition);
        }

        if (RandCreated == false && RelativePosition > 100f)
        {
            RandCueSide = UnityEngine.Random.value;
            RandCreated = true;
        }

        if (RandStimVersion == 0)
        {
            StimVersion = "Corridor"; 
        }
        if (RandStimVersion == 1)
        {
            StimVersion = "Panel";
        }

        if (StimDistance > 0 && RandDist != PrevRandDist && RandReceived == false && RandCreated == true) // not equal to 
        {
            RandReceived = true;
            PrevRandDist = RandDist;
        }

        if (LCamDistance > 0 && RelativePosition > (StimDistance - 1.0f) && StimDistance > 0)
        {
            PositionReached = true;          
        }


        if (AlternateNoCue == true && CueOrNotCreated == false)
        {
            CueOrNot = UnityEngine.Random.value;
            CueOrNotCreated = true;
        }

        if (CueOrNot < 0.4)
        {
            NoCue = true;
        }
        else
        {
            NoCue = false;
        }

        //sets up cueing if cued condition is true 
        if (NoCue == false && Cued == true && PositionReached == true && RandStimVersion > 2 && CueStarted == false)
        {

            if (RandCueSide < 0.5f && RandCueSide != 0) 
            {
                LeftCue.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + CueOffset);
            }

            if (RandCueSide >= 0.5f) 
            {
                RightCue.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + CueOffset);
            }


            CueStarted = true;

        }

        if (CueStarted == true)
        {
            CueTimer += Time.deltaTime;
        }

        if (CueTimer > CuePresentTime)
        {
            RightCue.transform.position = new Vector3(RightCueX, 2.5f, RelativePosition + CueOffset);
            LeftCue.transform.position = new Vector3(LeftCueX, 2.5f, RelativePosition + CueOffset);
            FakeCue.transform.position = new Vector3(-10.0f, 0.5f, 0.0f);
        }

        if (CueTimer > CuePresentTime + CueStimGap)
        {
            CueShown = true;
        }




        if (GameMode == GameVersion.BilateralCorridorTraining)

        {

            if (PositionReached == true) 
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;

                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;
                VertTrialCount = VertTrialCount + 1;
                //StimStartTime = Timer; 
                RandReceived = false;
                PositionReached = false;
                RandDist = 0;
                VStimTriggered = true;

            }
        }



        if (GameMode == GameVersion.AlternateBilateralStim)
        {

                if (RandStimVersion == 0 && PositionReached == true)
                {

                    Panel = false;
                    SmallStim = false; 
                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    LeftSmallVert.transform.position = new Vector3(0.0f, 2.5f, RelativePosition + StimOffset);
                    RightSmallVert.transform.position = new Vector3(0.0f, 2.5f, RelativePosition + StimOffset);
                    LeftVertGrating.transform.position = LeftVertDefault;
                    RightVertGrating.transform.position = RightVertDefault;

                    transform.position = new Vector3(0.0f, 0.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(0.0f, 0.0f, RelativePosition);

                    StimMoved = false;
                    PositionReached = false;
                    VStimTriggered = true;  
                }

                //Alternating with Bilateral Small Stim 
                if (Small == true && RandStimVersion == 1 && PositionReached == true)
                {
                        SmallStim = true;
                        Panel = true; 

                        LastPosition = position;
                        RelativePosition = position - LastPosition;

                        LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                        RightVertGrating.transform.position = RightVertGratingDisplaced;


                    if (BilateralStim == true)
                    {
                        RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, 0.0f + StimOffset);
                    }
                    else
                    {
                        RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, 0.0f + StimOffset);
                        LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, 0.0f + StimOffset);
                    }

                    StimMoved = true;
                    PositionReached = false;
            }


                if (StimMoved == true)
                {
                        transform.position = new Vector3(0.0f, 0.0f, RelativePosition);
                        RightEye.transform.position = new Vector3(0.0f, 0.0f, RelativePosition);

                        StimTrialCount = StimTrialCount + 1;


                        StimMoved = false;
                        StimStarted = true;
                        VStimTriggered = true;
                        RandCreated = false;
                       
                }

                if (StimStarted == true && Panel == true)
                {
                    StimTimer += Time.deltaTime;
                    MoveVStim = true;                  
                }


                if (MoveVStim == true && StimTimer > StimPresentationTime) // StimStarted == true && Static == false
                {
                    LeftSmallVert.transform.position = new Vector3(20.0f, 2.5f, StimOffset);
                    RightSmallVert.transform.position = new Vector3(20.0f, 2.5f, StimOffset);

                    StimStarted = false;
                    MoveVStim = false;
                    StimTimer = 0;
                    RandReceived = false;
                    Panel = false;
                }

            }

        if (GameMode == GameVersion.LowContrastDetection)
        {
            StimVersion = "Panel"; 

            if (PositionReached == true)
            {

                Panel = true;
                LastPosition = position;
                RelativePosition = position - LastPosition;

                if(BilateralStim == true)
                {
                    RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, 0.0f + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, 0.0f + StimOffset);
                }
                else
                {
                    RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, 0.0f + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(20.0f, 2.5f, 0.0f + StimOffset);
                }

                StimMoved = true;
                PositionReached = false;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
            }


            if (StimMoved == true)
            {
                transform.position = new Vector3(0.0f, 0.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 0.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;

                StimMoved = false;
                StimStarted = true;
                VStimTriggered = true;
                RandCreated = false;
            }

            if (StimStarted == true && Panel == true)
            {
                StimTimer += Time.deltaTime;
                MoveVStim = true;
            }


            if (MoveVStim == true && StimTimer > StimPresentationTime) // StimStarted == true && Static == false
            {
                LeftSmallVert.transform.position = new Vector3(20.0f, 2.5f, StimOffset);
                RightSmallVert.transform.position = new Vector3(20.0f, 2.5f, StimOffset);

                StimStarted = false;
                MoveVStim = false;
                StimTimer = 0;
                RandReceived = false;
                Panel = false;
            }

        }

        if (GameMode == GameVersion.CuedLowContrastDetection)
        {
            StimVersion = "Panel";

            if ((NoCue == false && PositionReached == true && CueTimer > CuePresentTime && CueShown == true) || (NoCue == true && PositionReached == true))
            {

                Panel = true;
                LastPosition = position;
                RelativePosition = position - LastPosition;

                if (BilateralStim == true)
                {
                    RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, 0.0f + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, 0.0f + StimOffset);
                }
                else
                {
                    RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, 0.0f + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(20.0f, 2.5f, 0.0f + StimOffset);
                }

                StimMoved = true;
                PositionReached = false;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
            }


            if (StimMoved == true)
            {
                transform.position = new Vector3(0.0f, 0.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 0.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;

                StimMoved = false;
                StimStarted = true;
                VStimTriggered = true;
                RandCreated = false;
            }

            if (StimStarted == true && Panel == true)
            {
                StimTimer += Time.deltaTime;
                MoveVStim = true;
            }


            if (MoveVStim == true && StimTimer > StimPresentationTime) // StimStarted == true && Static == false
            {
                LeftSmallVert.transform.position = new Vector3(20.0f, 2.5f, StimOffset);
                RightSmallVert.transform.position = new Vector3(20.0f, 2.5f, StimOffset);

                StimStarted = false;
                MoveVStim = false;
                StimTimer = 0;
                RandReceived = false;
                Panel = false;
            }

        }




        if (VStimTriggered == true)
        {
            TextToSend = "1";

            if (SmallStim == true)
            {
                TextToSend = TextToSend + "S";
            }
            else
            {
                TextToSend = TextToSend + "N";
            }

            if (Cued == true)
            {
                if (NoCue == false)
                {
                    if (RandCueSide < 0.5f && RandCueSide != 0)
                    {
                        TextToSend = TextToSend + "L";
                    }
                    else if (RandCueSide >= 0.5f)
                    {
                        TextToSend = TextToSend + "R";
                    }
                }
                if (NoCue == true)
                {
                    TextToSend = TextToSend = TextToSend + "N";
                }
            }
            else
            {
                TextToSend = TextToSend = TextToSend + "X";
            }

        }


        if (FlashSide == 1)
        {
            TextToSend = TextToSend + "1";
        }
        if (FlashSide == 2)
        {
            TextToSend = TextToSend + "2";
        }
        if (FlashSide == 0)
        {
            TextToSend = TextToSend + "0";
        }



        if (StimReceived > 0 && StimStarted == false)
        {
            VStimTriggered = false;
        }
    }




    void LateUpdate()
    {

        LCamDistance = transform.position.z;

        if (FakeCueTimer > 0 && FakeCueTimer < CuePresentTime && RandSide < 0.5f && RandSide != 0)
        {
            FakeCue.transform.position = new Vector3(-4.98f, 2.5f, LCamDistance + StimOffset);
        }

        if (FakeCueTimer > 0 && FakeCueTimer < CuePresentTime && RandSide >= 0.5f)
        {
            FakeCue.transform.position = new Vector3(4.98f, 2.5f, LCamDistance + StimOffset);
        }

        if (CueTimer > 0 && CueTimer < CuePresentTime && RandCueSide < 0.5f && RandCueSide != 0)
        {
            LeftCue.transform.position = new Vector3(-4.98f, 2.5f, LCamDistance + StimOffset);
        }

        if (CueTimer > 0 && CueTimer < CuePresentTime && RandCueSide >= 0.5f)
        {
            RightCue.transform.position = new Vector3(4.98f, 2.5f, LCamDistance + StimOffset);
        }

        if (MoveVStim == true)
        {
            if (GameMode == GameVersion.AlternateBilateralStim)
            {
                LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
            }

            if (GameMode == GameVersion.LowContrastDetection || GameMode == GameVersion.CuedLowContrastDetection)
            {
                if(BilateralStim == true)
                {
                    RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                }
                else
                {
                    RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(20.0f, 2.5f, LCamDistance + StimOffset);
                }
            }
        }


    }

    void FixedUpdate()
    {

        //reset position at start
        if (ResetSesh == 1)
        {
            transform.position = new Vector3(0.0f, 1.0f, 0.0f);
            RightEye.transform.position = new Vector3(0.0f, 1.0f, 0.0f);
            StimDistance = 0;
            RandReceived = false;
            LastPosition = 0; 
            RelativePosition = 0;
            StimTrialCount = 0;

        }
    }

    // receive thread 
    private void ReceiveData()
    {
        print("allocating client");
        IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, ReceivePort);
        client = new UdpClient(ReceivePort);
        client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (receiveRunning)
        {
            try
            {
                data = client.Receive(ref anyIP); //byte[] data
                text = Encoding.UTF8.GetString(data);
                // latest UDPpacket
                lastReceivedUDPPacket = text;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    private void SendData()
    {
        print("sending client");
        IPEndPoint SendtoIP = new IPEndPoint(IPAddress.Parse(SendIP), SendPort);
        SendClient = new UdpClient(SendPort);
        SendClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (sendRunning)
        {
            try
            {
                DataToSend = Encoding.UTF8.GetBytes(TextToSend);
                SendClient.Send(DataToSend, DataToSend.Length, SendtoIP);
                lastSentUDPPacket = TextToSend;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    public string getLatestUDPPacket()
    {
        return lastReceivedUDPPacket;
        return lastSentUDPPacket;
    }

    void OnApplicationQuit()
    {
        // stop listening thread
        receiveRunning = false;
        sendRunning = false;
        client.Close();
        SendClient.Close();

        // wait for listening thread to terminate (max. 500ms)		
        receiveThread.Join(500);
        sendThread.Join(500);
    }

}