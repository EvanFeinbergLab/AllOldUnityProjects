﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

//[RequireComponent(typeof(AudioSource))]

public class MasterCtrl : MonoBehaviour
{
    private enum GameVersion {SelfInitiateTraining,
                             DiscriminationTraining,
                             ForcedChoiceTask,
                             CuedForcedChoiceTask};

    private GameVersion GameMode;
    public string Task;
    public bool SmallStim;
    public bool Cued;
    public bool AlternateNoCue;

    public string StimIdentity;
    public string StimSide; 

    public float StimPresentationTime;
    public float CuePresentTime; 
    public float CueStimGap; 
    public float StimOffset;

    public string lastReceivedUDPPacket = "";
    public string lastSentUDPPacket = "";

    public int StimTrialCount;
    private int VertTrialCount;
    public float RelativePosition;
    private float StimDist; 

    private Vector3 GroundCoord;
    private Vector3 CeilingCoord;
    private Vector3 VertGreyRWCoord;
    private Vector3 VertGreyLWCoord;
    private Vector3 NewPosition;
    private Vector3 LeftVertDefault;
    private Vector3 RightVertDefault;
    private Vector3 LeftVertGratingDisplaced;
    private Vector3 RightVertGratingDisplaced;
    private Vector3 LeftDiagGratingDisplaced;
    private Vector3 RightDiagGratingDisplaced;
    private Vector3 Location;

    UdpClient client;
    UdpClient SendClient;
    private Thread receiveThread;
    private Thread sendThread;

    private bool receiveRunning;
    private bool sendRunning;
    private bool PositionReached;
    private bool VStimTriggered;
    private bool DStimTriggered;

    public bool StimStarted;
    public bool RandDistCreated;
    private bool RandSideCreated;
    private bool CueShown;
    private bool TimerStarted;
    private bool StimMoved;
    private bool CueStarted;
    private bool ContrastSet;
    private bool MoveVStim;
    private bool MoveDStim; 

    public bool NoCue;
    private bool CueOrNotCreated;
    public bool StartStim;
    public bool StimEnded; 

    private int StimReceived;
    private int stringSize;
    private int resetPos;
    public float RandDist;
    private int TaskVersion;
    private int StimulusSide; 

    private int FwdInstanNum;
    private int RevInstanNum;
    private int InstanLength;
    private int origin;
    private int revNum;
    public int StartBeep;
    public bool Beep;  

    private int SendPort;
    private int ReceivePort;
    private byte[] data;
    private byte[] DataToSend;

    private int ContrastVersion;
    private int StimReady;
    private int EndStim;  

    private string ContrastLevel;
    private string Mode;
    private string StimResponse;
    public string StimVersion;
    private string SelfInitiated;
    private string NewTrial; 

    private string text;
    private string TextToSend;
    private string PosIn;
    private string udpIn;
    private string udpOut;
    private string SendIP;   
    private string LVMessage; 

    private float DiagRandZ;
    public float StimTimer; 
    private float CueTimer;
    private float NextDot;
    private float RandStim;

    private float RandSide;
    private float LastDist;
    private float CueOrNot;
    private float RandCueSide;
    private float LastPosition;
    private float RandPunish;

    private float LCamDistance;
    private float position; //UDP position
    private float smoothing;
    private float fracMovt;

    private float CueOffset;
    private float RightCueX;
    private float LeftCueX;
    private float CurrLeftCueX;
    private float CurrRightCueX;

    private float deltaTime; 

    private GameObject VCeilingClone;
    private GameObject RevVCeilingClone;
    private GameObject VGrndClone;
    private GameObject RevVGrndClone;
    private GameObject VRWClone;
    private GameObject VLWClone;

    public GameObject LeftCue;
    public GameObject RightCue;
    public GameObject FakeCue;

    public GameObject VertFullContrastR;
    public GameObject VertContrast1R;
    public GameObject VertContrast2R;
    public GameObject VertContrast3R;
    public GameObject VertContrast4R;
    public GameObject VertContrast5R;
    public GameObject VertContrast6R;
    public GameObject VertContrast7R;
    public GameObject VertContrast8R;
    public GameObject VertNoContrastR;
    public GameObject VertFullContrastL;
    public GameObject VertContrast1L;
    public GameObject VertContrast2L;
    public GameObject VertContrast3L;
    public GameObject VertContrast4L;
    public GameObject VertContrast5L;
    public GameObject VertContrast6L;
    public GameObject VertContrast7L;
    public GameObject VertContrast8L;
    public GameObject VertNoContrastL;

    public GameObject DiagFullContrastR;
    public GameObject DiagContrast1R;
    public GameObject DiagContrast2R;
    public GameObject DiagContrast3R;
    public GameObject DiagContrast4R;
    public GameObject DiagContrast5R;
    public GameObject DiagContrast6R;
    public GameObject DiagContrast7R;
    public GameObject DiagContrast8R;
    public GameObject DiagNoContrastR;
    public GameObject DiagFullContrastL;
    public GameObject DiagContrast1L;
    public GameObject DiagContrast2L;
    public GameObject DiagContrast3L;
    public GameObject DiagContrast4L;
    public GameObject DiagContrast5L;
    public GameObject DiagContrast6L;
    public GameObject DiagContrast7L;
    public GameObject DiagContrast8L;
    public GameObject DiagNoContrastL;

    private GameObject LeftVert;
    private GameObject RightVert;
    private GameObject LeftDiag;
    private GameObject RightDiag; 

    public GameObject LeftEye;
    public GameObject RightEye;
    public GameObject VertCeiling;
    public GameObject VertGreyRW;
    public GameObject VertGreyLW;
    public GameObject LightWall; 
    public GameObject VertGround;
    public GameObject BlackDot; 

    public Material Black;
    public Material LightGrey;
    public Material White;

    private string WrongLick;
    private int DistPunish;
    


    void Awake()
    {
        for (int i = 1; i < 41; i++)
        { 
            GameObject VCeilingClone = Instantiate(VertCeiling) as GameObject;
            VCeilingClone.transform.position = new Vector3(0.0f, 5.0f, i * 50.0f + 25f);          

            GameObject VLWClone = Instantiate(VertGreyLW) as GameObject;
            GameObject VRWClone = Instantiate(VertGreyRW) as GameObject;

            VLWClone.transform.position = new Vector3(-5.01f, 2.5f, i * 50.0f);
            VRWClone.transform.position = new Vector3(5.01f, 2.5f, i * 50.0f);

            GameObject VGrndClone = Instantiate(VertGround) as GameObject;
            VGrndClone.transform.position = new Vector3(0.0f, -2.0f, i * 100.0f + 10f);
        }

        for (int i = 1; i < 4; i++)
        {
            GameObject RevVCeilingClone = Instantiate(VertCeiling) as GameObject;
            RevVCeilingClone.transform.position = new Vector3(0.0f, 5.0f, i * -50.0f + 25f);

            GameObject RevVGrndClone = Instantiate(VertGround) as GameObject;
            RevVGrndClone.transform.position = new Vector3(0.0f, -2.0f, i * -100.0f + 10f);

            GameObject RevVLWClone = Instantiate(VertGreyLW) as GameObject;
            GameObject RevVRWClone = Instantiate(VertGreyRW) as GameObject;

            RevVLWClone.transform.position = new Vector3(-5.01f, 2.5f, i * -50.0f);
            RevVRWClone.transform.position = new Vector3(5.01f, 2.5f, i * -50.0f);

        }

        for (int i = 0; i < 10; i++)
        {
            GameObject LightWallClone = Instantiate(LightWall) as GameObject;
            LightWallClone.transform.position = new Vector3(5.0f, 2.5f, i * 200.0f + 50f);
        }

        TextToSend = "0";
        StimTrialCount = 0;
        RelativePosition = 0;
        StimTimer = 0;
        CueShown = false;
        CueTimer = 0; 
    }       

    void Start()
    {
        Debug.Log("displays connected:" + Display.displays.Length);

        init();
        Application.runInBackground = true;

        CueOffset = StimOffset;
        LeftCueX = LeftCue.transform.position.x;
        RightCueX = RightCue.transform.position.x;
        NoCue = false;

        StimIdentity = "N";
        RandDistCreated = false;
        RandSideCreated = false;


    }

    public void Activate()
    {
        Screen.fullScreen = true;
    }

    private void init()
    {
        print("UDP.init()");

        ReceivePort = 8888;
        SendPort = 8051;
        SendIP = "169.230.68.194";

        receiveRunning = true;
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();

        sendRunning = true;
        sendThread = new Thread(new ThreadStart(SendData));
        sendThread.IsBackground = true;
        sendThread.Start();
    }


    void Update()
    {
        TextToSend = "0";

        udpIn = lastReceivedUDPPacket;
        stringSize = udpIn.Length;

        if (stringSize > 0)
        {
            Mode = udpIn.Substring(0, 1);
            StimVersion = udpIn.Substring(1, 1);
            StimIdentity = udpIn.Substring(2, 1);
            SelfInitiated = udpIn.Substring(3, 1);
            StimResponse = udpIn.Substring(4, 1);
            NewTrial = udpIn.Substring(6, 1);
            ContrastLevel = udpIn.Substring(5, 1);
            PosIn = udpIn.Substring(7, (stringSize - 7));
        }

        int.TryParse(Mode, out TaskVersion);
        int.TryParse(ContrastLevel, out ContrastVersion);
        int.TryParse(SelfInitiated, out StimReady);
        int.TryParse(StimResponse, out EndStim);
        int.TryParse(StimVersion, out StimulusSide);
        int.TryParse(NewTrial, out StartBeep);
        float.TryParse(PosIn, out position);      

        RelativePosition = position - LastPosition;
        LCamDistance = LeftEye.transform.position.z;

        if (StartBeep == 1 && Beep == false)
        {
            AudioSource audio = GetComponent<AudioSource>();
            audio.Play();
            Beep = true; 
        }

        if(StartBeep == 0 && Beep == true)
        {
            Beep = false; 
        }

        if(TaskVersion == 0)
        {
            GameMode = GameVersion.SelfInitiateTraining; 
        }
        if (TaskVersion == 1)
        {
            GameMode = GameVersion.DiscriminationTraining;
        }
        if (TaskVersion == 2)
        {
            GameMode = GameVersion.ForcedChoiceTask;
        }
        if (TaskVersion == 3)
        {
            GameMode = GameVersion.CuedForcedChoiceTask;
        }

        if (GameMode == GameVersion.CuedForcedChoiceTask)
        {
            Cued = true;
            AlternateNoCue = true;
            CueOrNot = 0;
            CueStarted = false;
        }

        //Cam Movement 
        if (position != LCamDistance)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, RelativePosition);
            RightEye.transform.position = new Vector3(transform.position.x, transform.position.y, RelativePosition);
        }

        if (GameMode == GameVersion.DiscriminationTraining || GameMode == GameVersion.ForcedChoiceTask)
        {
            RightVert = VertFullContrastR;
            LeftVert = VertFullContrastL;
            RightDiag = DiagFullContrastR;
            LeftDiag = DiagFullContrastL;
        }

        if (GameMode == GameVersion.CuedForcedChoiceTask)          
        {
                if (ContrastVersion == 0)
                {
                    RightVert = VertFullContrastR;
                    LeftVert = VertFullContrastL;
                    RightDiag = DiagFullContrastR;
                    LeftDiag = DiagFullContrastL;
            }

                if (ContrastVersion == 1)
                {
                    RightVert = VertContrast1R;
                    LeftVert = VertContrast1L;
                    RightDiag = DiagContrast1R;
                    LeftDiag = DiagContrast1L;
            }

                if (ContrastVersion == 2)
                {
                    RightVert = VertContrast2R;
                    LeftVert = VertContrast2L;
                    RightDiag = DiagContrast2R;
                    LeftDiag = DiagContrast2L;
                }

                if (ContrastVersion == 3)
                {
                    RightVert = VertContrast3R;
                    LeftVert = VertContrast3L;
                    RightDiag = DiagContrast3R;
                    LeftDiag = DiagContrast3L;

                 }
    
                if (ContrastVersion == 4)
                {
                    RightVert = VertContrast4R;
                    LeftVert = VertContrast4L;
                    RightDiag = DiagContrast4R;
                    LeftDiag = DiagContrast4L;
                 }

                if (ContrastVersion == 5)
                {
                    RightVert = VertContrast5R;
                    LeftVert = VertContrast5L;
                    RightDiag = DiagContrast5R;
                    LeftDiag = DiagContrast5L;
                }

                if (ContrastVersion == 6)
                {
                    RightVert = VertContrast6R;
                    LeftVert = VertContrast6L;
                    RightDiag = DiagContrast6R;
                    LeftDiag   = DiagContrast6L;
            }

                if (ContrastVersion == 7)
                {
                    RightVert = VertContrast7R;
                    LeftVert = VertContrast7L;
                    RightDiag = DiagContrast7R;
                    LeftDiag = DiagContrast7L;
            }

                if (ContrastVersion == 8)
                {
                    RightVert = VertContrast8R;
                    LeftVert = VertContrast8L;
                    RightDiag = DiagContrast8R;
                    LeftDiag = DiagContrast8L;
            }

                if (ContrastVersion == 9)
                {
                    RightVert = VertNoContrastR;
                    LeftVert = VertNoContrastL;
                    RightDiag = DiagNoContrastR;
                    LeftDiag = DiagNoContrastL;
            }
        }

        if (RandSideCreated == false)
        {
            RandCueSide = UnityEngine.Random.value;
            RandSideCreated = true;        
        }


        if (StimReady == 1)
        {
            StartStim = true;          
        }

        if (StimReady == 0)
        {
            StartStim = false;
        }

        if(TaskVersion == 0)
        {
            Task = "Self-Initiate Training"; 
        }
        if (TaskVersion == 1)
        {
            Task = "Discrmination Training";
        }
        if (TaskVersion == 2)
        {
            Task = "Forced Choice Discrimination";
        }

            if (StimulusSide == 1)
            {
                StimSide = "Left";
            }
            if (StimulusSide == 0)
            {
                StimSide = "Right";
            }
            if (StimulusSide == 2)
            {
                StimSide = "Bilateral";
            }
 


        if (AlternateNoCue == true && CueOrNotCreated == false)
        {
            CueOrNot = UnityEngine.Random.value; 
            CueOrNotCreated = true;
        }

        if (CueOrNot < 0.4)
        {
            NoCue = true;
        }
        else
        {
            NoCue = false;
        }


 
        if (Cued == true && StartStim == true && CueStarted == false)
        {
            if(NoCue == false)
            {
                if (RandCueSide < 0.5f && RandCueSide != 0)
                {
                    LeftCue.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + CueOffset);
                }

                if (RandCueSide >= 0.5f)
                {
                    RightCue.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + CueOffset);
                }
                CueStarted = true;
            }
            else
            {
                CueStarted = false;
            }
        }

        if (CueStarted == true)
        {
            CueTimer += Time.deltaTime;
        }

        if (CueTimer > CuePresentTime)
        {
            RightCue.transform.position = new Vector3(RightCueX, 2.5f, RelativePosition + CueOffset);
            LeftCue.transform.position = new Vector3(LeftCueX, 2.5f, RelativePosition + CueOffset);
            FakeCue.transform.position = new Vector3(-10.0f, 0.5f, 0.0f);
        }

        if (CueTimer > CuePresentTime + CueStimGap)
        {
            CueShown = true;
        }

        if (GameMode == GameVersion.SelfInitiateTraining)
        {
            if (RandDistCreated == false)
            {
                RandDist = UnityEngine.Random.Range(1200f, 1600f);
                RandDistCreated = true;
            }

            if (LCamDistance > RandDist && RandDistCreated == true)
            {
                LastPosition = position;
                RandDistCreated = false;

            }

            RelativePosition = position - LastPosition;
            transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
            RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
        }
            


        if (GameMode == GameVersion.DiscriminationTraining)
        {

            if (StimIdentity == "V" && StartStim == true)
            {
                RightVert.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                LeftVert.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);

                VStimTriggered = true;
                StimStarted = true;
                MoveVStim = true;
            }

            if (StimIdentity == "D" && StartStim == true)
            {
                RightDiag.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                LeftDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);

                DStimTriggered = true;
                StimStarted = true;
                MoveDStim = true;
            }

            if (EndStim == 1 && StimStarted == true)//(StimTimer > StimPresentationTime)
            {
                if (MoveVStim == true)
                {
                    LeftVert.transform.position = new Vector3(-15.0f, 2.5f, StimOffset);
                    RightVert.transform.position = new Vector3(15.0f, 2.5f, StimOffset);
                }

                if (MoveDStim == true)
                {
                    LeftDiag.transform.position = new Vector3(-30.0f, 2.5f, StimOffset);
                    RightDiag.transform.position = new Vector3(30.0f, 2.5f, StimOffset);
                }

                StimMoved = true;
                MoveVStim = false;
                MoveDStim = false;
                DStimTriggered = false;
                VStimTriggered = false;
                StimEnded = true; 
            }

            if (StimMoved == true)
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;
                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;

                StartStim = false; 
                StimStarted = false;
                StimEnded = false; 
                StimTimer = 0;
                StimMoved = false;
                RandSideCreated = false;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
            }

        }


        if (GameMode == GameVersion.ForcedChoiceTask)
        {
            //StimStarted = true;
            if (StimIdentity == "V" && StartStim == true)
            {
                if (StimulusSide == 0) // Right  
                {
                    RightVert.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);
                    LeftVert.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                }

                if (StimulusSide == 1) //Left
                {
                    RightVert.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                    LeftVert.transform.position = new Vector3(-15.0f, 2.5f, RelativePosition + StimOffset);
                }

                if (StimulusSide == 2) //bilateral 
                {
                    RightVert.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                    LeftVert.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                }

                VStimTriggered = true;
                StimStarted = true;
                MoveVStim = true;
            }

            if (StimIdentity == "D" && StartStim == true)
            {

                if (StimulusSide == 0) // Right
                {
                    RightDiag.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);
                    LeftDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                }

                if (StimulusSide == 1) //Left
                {
                    RightDiag.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                    LeftDiag.transform.position = new Vector3(-15.0f, 2.5f, RelativePosition + StimOffset);
                }

                if (StimulusSide == 2)// Bilateral
                {
                    RightDiag.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                    LeftDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                }

                DStimTriggered = true;
                StimStarted = true;
                MoveDStim = true;
            }


            if (EndStim == 1 && StimStarted == true)
            {
                if (MoveVStim == true)
                {
                    LeftVert.transform.position = new Vector3(-15.0f, 2.5f, StimOffset);
                    RightVert.transform.position = new Vector3(15.0f, 2.5f, StimOffset);
                }

                if (MoveDStim == true)
                {
                    LeftDiag.transform.position = new Vector3(-30.0f, 2.5f, StimOffset);
                    RightDiag.transform.position = new Vector3(30.0f, 2.5f, StimOffset);
                }

                StimMoved = true;
                MoveVStim = false;
                MoveDStim = false;
                DStimTriggered = false;
                VStimTriggered = false;
                StimEnded = true; 
            }


            if (StimMoved == true)
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;
                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                //StimTrialCount = StimTrialCount + 1;

                StartStim = false; 
                StimStarted = false;
                StimTimer = 0;
                StimMoved = false;
                RandSideCreated = false;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
            }

        }



        if (GameMode == GameVersion.CuedForcedChoiceTask)
        {

            if ((NoCue == false && StartStim == true && CueTimer > CuePresentTime && CueShown == true) || (NoCue == true && StartStim == true))
            {

                if (StimIdentity == "V" && StartStim == true)
                {
                    if (StimulusSide == 0)
                    {
                        RightVert.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);
                        LeftVert.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                    }

                    if (StimulusSide == 1)
                    {
                        RightVert.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                        LeftVert.transform.position = new Vector3(-15.0f, 2.5f, RelativePosition + StimOffset);
                    }

                    VStimTriggered = true;
                    StimStarted = true;
                    MoveVStim = true;
                }

                if (StimIdentity == "D" && StartStim == true)
                {
                    if (StimulusSide == 0)
                    {
                        RightDiag.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);
                        LeftDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                    }

                    if (StimulusSide == 1)
                    {
                        RightDiag.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                        LeftDiag.transform.position = new Vector3(-15.0f, 2.5f, RelativePosition + StimOffset);
                    }

                    DStimTriggered = true;
                    StimStarted = true;
                    MoveDStim = true;
                }
            }


            if (StimStarted == true)
            {
                StimTimer += Time.deltaTime;
            }


            if (StimTimer > StimPresentationTime)
            {
                if (MoveVStim == true)
                {
                    LeftVert.transform.position = new Vector3(-15.0f, 2.5f, StimOffset);
                    RightVert.transform.position = new Vector3(15.0f, 2.5f, StimOffset);
                }

                if (MoveDStim == true)
                {
                    LeftDiag.transform.position = new Vector3(-30.0f, 2.5f, StimOffset);
                    RightDiag.transform.position = new Vector3(30.0f, 2.5f, StimOffset);
                }

                StimMoved = true;
                MoveVStim = false;
                MoveDStim = false;
                DStimTriggered = false;
                VStimTriggered = false; 
            }

            if (StimMoved == true && StimTimer > StimPresentationTime + 2.0f)
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;
                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;

                StimStarted = false;
                StimTimer = 0;
                StimMoved = false;
                RandSideCreated = false;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
            }

        }


      if (SmallStim == true)
        {
           TextToSend = TextToSend + "S";
        }
     else
        {
          TextToSend = TextToSend + "N";
        }

        if (StimSide == "Right")
        {
            TextToSend = TextToSend + "R";
        }       

        if (StimSide == "Left")
        {
            TextToSend = TextToSend + "L";
        }
        if (StimSide == "Both")
        {
            TextToSend = TextToSend + "B";
        }

        if (Cued == true)
            {
                if (NoCue == false)
                {
                    if (RandCueSide < 0.5f && RandCueSide != 0)
                    {
                        TextToSend = TextToSend + "L";
                    }
                    else if (RandCueSide >= 0.5f)
                    {
                        TextToSend = TextToSend + "R";
                    }
                }
                if (NoCue == true)
                {
                    TextToSend = TextToSend = TextToSend + "N";
                }
            }
            else
            {
                TextToSend = TextToSend = TextToSend + "X";
            }

    }




    void LateUpdate()
    {

        LCamDistance = transform.position.z;

        if (CueTimer > 0 && CueTimer < CuePresentTime && RandCueSide < 0.5f && RandCueSide != 0)
        {
            LeftCue.transform.position = new Vector3(-4.98f, 2.5f, LCamDistance + StimOffset);
        }

        if (CueTimer > 0 && CueTimer < CuePresentTime && RandCueSide >= 0.5f)
        {
            RightCue.transform.position = new Vector3(4.98f, 2.5f, LCamDistance + StimOffset);
        }

        if (MoveVStim == true)
        {
            if (GameMode == GameVersion.DiscriminationTraining)
            {
                LeftVert.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                RightVert.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
            }

            if (GameMode == GameVersion.ForcedChoiceTask || GameMode == GameVersion.CuedForcedChoiceTask)
            {
                if (StimulusSide == 0)
                {
                    RightVert.transform.position = new Vector3(10.0f, 2.5f, LCamDistance + StimOffset);
                    LeftVert.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                }
                if (StimulusSide == 1)
                {
                    RightVert.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
                    LeftVert.transform.position = new Vector3(-30.0f, 2.5f, LCamDistance + StimOffset);
                }
            }
        }

        if (MoveDStim == true)
        {
            if (GameMode == GameVersion.DiscriminationTraining)
            {
                LeftDiag.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                RightDiag.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
            }

            if (GameMode == GameVersion.ForcedChoiceTask || GameMode == GameVersion.CuedForcedChoiceTask)
            {
                if (StimulusSide == 0)
                {
                    RightDiag.transform.position = new Vector3(10.0f, 2.5f, LCamDistance + StimOffset);
                    LeftDiag.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                }
                if (StimulusSide == 1)
                {
                    RightDiag.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
                    LeftDiag.transform.position = new Vector3(-30.0f, 2.5f, LCamDistance + StimOffset);
                }
            }
        }
    }

    void FixedUpdate()
    {

    }

    // receive thread 
    private void ReceiveData()
    {
        print("allocating client");
        IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, ReceivePort);
        client = new UdpClient(ReceivePort);
        client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (receiveRunning)
        {
            try
            {
                data = client.Receive(ref anyIP); //byte[] data
                text = Encoding.UTF8.GetString(data);
                // latest UDPpacket
                lastReceivedUDPPacket = text;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    private void SendData()
    {
        print("sending client");
        IPEndPoint SendtoIP = new IPEndPoint(IPAddress.Parse(SendIP), SendPort);
        SendClient = new UdpClient(SendPort);
        SendClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (sendRunning)
        {
            try
            {
                DataToSend = Encoding.UTF8.GetBytes(TextToSend);
                SendClient.Send(DataToSend, DataToSend.Length, SendtoIP);
                lastSentUDPPacket = TextToSend;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    public string getLatestUDPPacket()
    {
        return lastReceivedUDPPacket;
        return lastSentUDPPacket;
    }

    void OnApplicationQuit()
    {
        // stop listening thread
        receiveRunning = false;
        sendRunning = false;
        client.Close();
        SendClient.Close();

        // wait for listening thread to terminate (max. 500ms)		
        receiveThread.Join(500);
        sendThread.Join(500);
    }

}