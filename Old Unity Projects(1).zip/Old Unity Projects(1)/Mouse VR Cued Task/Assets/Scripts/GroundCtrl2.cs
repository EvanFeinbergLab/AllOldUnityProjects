﻿using UnityEngine;
using System.Collections;

public class GroundCtrl2 : MonoBehaviour
{

    public GameObject Ground;

    void Start()
    {
        //set to 5000 for decent length and load time at start 
        for (int i = 0; i < 200; i++)
        {
            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GroundClone.transform.position = new Vector3(transform.position.x, transform.position.y, i * -40.0F);

        }
    }
}
