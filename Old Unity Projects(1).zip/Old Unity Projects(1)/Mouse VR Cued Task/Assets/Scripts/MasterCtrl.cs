﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class MasterCtrl : MonoBehaviour
{
        public enum GameVersion {BilateralStimDotsTraining,
                                  BilateralStim,
                                  LeftCuedDynamic,
                                  RightCuedDynamic};

    public GameVersion GameMode;
    public bool LeftUnilateral;
    public bool RightUnilateral;
    public bool SmallStim; 
    public bool Cued; 
    public bool StaticStim;

    public bool LoopRan; 

    public float StimPresentationTime;
    public float CueLength; 


    private Vector3 GroundCoord;
    private Vector3 CeilingCoord;
    private Vector3 DiagGreyRWCoord;
    private Vector3 DiagGreyLWCoord;
    private Vector3 VertGreyRWCoord;
    private Vector3 VertGreyLWCoord;
    private Vector3 NewPosition;
    private Vector3 LeftDiagDefault;
    private Vector3 RightDiagDefault;
    private Vector3 LeftVertDefault;
    private Vector3 RightVertDefault;
    private Vector3 LeftDiagGratingDisplaced;
    private Vector3 RightDiagGratingDisplaced;
    private Vector3 LeftVertGratingDisplaced;
    private Vector3 RightVertGratingDisplaced;


    private Vector3 Location;
    public float RandStim;
    public float RandStimVersion;

    UdpClient client;
    UdpClient SendClient;
    private Thread receiveThread;
    private Thread sendThread;

    private bool receiveRunning;
    private bool sendRunning;
    private bool Reset;
    private bool Transported;
    private bool RandReceived;
    public bool PositionReached;
    private bool DiagCloneAppeared;
    private bool VertCloneAppeared;
    private bool DStimTriggered;
    private bool VStimTriggered;
    private bool TooFar;
    public bool CueStarted;
    private bool StimStarted;
    private bool RandCreated;
    public bool CueShown;
    public bool Static;
    public bool TimerStarted;
    public bool StimMoved; 

    private bool MoveLeftCuedVert; 
    private bool MoveLeftCuedDiag;
    private bool MoveRightCuedVert;
    private bool MoveRightCuedDiag;
    private bool MoveDStim;
    private bool MoveVStim;
    private bool VariantVersion; 

    private int ResetSesh;
    private int StimReceived;
    private int stringSize;
    private int resetPos;
    //private int RandDist;
    private float RandDist; 

    private int FwdInstanNum;
    private int RevInstanNum;
    private int InstanLength;
    private int origin;

    private int revNum; 

    private int SendPort;
    private int ReceivePort;
    private byte[] data;
    private byte[] DataToSend;

    private string text;
    private string TextToSend;
    private string PosIn;
    private string RandNum;
    private string StimTrig;
    private string NewTrial;
    private string itString;
    private string RWCloneName;
    private string LWCloneName;
    private string ReceivedStim;
    private string ResetSession;

    private string CloneNum;
    private string udpIn;
    private string udpOut;
    private string LCloneName;
    private string RCloneName;
    private string FWallCloneNum;
    private string BWallCloneNum;
    private string StimWindow;
    private string Task;
    private string SendIP;
    private string FindCloneNum;
    private string FindLWCloneName;
    private string FindRWCloneName;
    private string DotI;
    private string FindDotI;

    private float[] VertYCoords;
    private float[] DiagYCoords;
    private float DiagRandZ;
    private float LastPosition;
    private float deltaTime;
    public float CueTimer;
    public float StimTimer; 
    private float LDStimX;
    private float LVStimX;
    private float RDStimX;
    private float RVStimX;
    private float CorridorLocation;

    private float RCamDistance; //cam location
    private float LCamDistance;
    private float position; //UDP position
    private float smoothing;
    private float fracMovt;

    private float PrevRandDist;
    private float offset;
    public float StimOffset;
    private float CueOffset;
    private float RandDot;

    private float DiagRandY;
    private float VertRandY;
    private float VRandY;
    private float DRandY; 
    private float VertRandDot;
    private float DiagRandDot;
    private float DotCueX;
    private float CurrDotCueX;
    private float RandCueSide;

    private GameObject DRBDotClone;
    private GameObject DLBDotClone;
    private GameObject DRWDotClone;
    private GameObject DLWDotClone;
    private GameObject VRBDotClone;
    private GameObject VLBDotClone;
    private GameObject VRWDotClone;
    private GameObject VLWDotClone;
    private GameObject DShuffleRDot;
    private GameObject DShuffleLDot;
    private GameObject VShuffleRDot;
    private GameObject VShuffleLDot;
    private GameObject WhiteDotClone;
    private GameObject BlackDotClone;

    private GameObject DCeilingClone;
    private GameObject VCeilingClone;
    private GameObject RevDCeilingClone;
    private GameObject RevVCeilingClone;

    private GameObject DGrndClone;
    private GameObject VGrndClone;
    private GameObject RevDGrndClone;
    private GameObject RevVGrndClone;
    private GameObject DRWClone;
    private GameObject DLWClone;
    private GameObject VRWClone;
    private GameObject VLWClone;

    //public AudioSource Lcrinkle;
    // public AudioSource Rcrinkle;

    public string lastReceivedUDPPacket = "";
    public string lastSentUDPPacket = "";

    public int StimTrialCount;
    public int VertTrialCount; 
    public string StimIdentity;
    public float RelativePosition; 

    public float StimDistance;
    public float fps;

    public GameObject DotCue;
    public GameObject LeftDiagGrating;
    public GameObject RightDiagGrating;
    public GameObject LeftVertGrating;
    public GameObject RightVertGrating;
    public GameObject LeftSmallDiag;
    public GameObject RightSmallDiag;
    public GameObject LeftSmallVert;
    public GameObject RightSmallVert;


    public GameObject LeftEye;
    public GameObject RightEye;
    public GameObject DiagCeiling;
    public GameObject VertCeiling;
    public GameObject DiagGreyRW;
    public GameObject DiagGreyLW;
    public GameObject VertGreyRW;
    public GameObject VertGreyLW;
    public GameObject DiagGround;
    public GameObject VertGround;
    public GameObject WhiteDot;
    public GameObject BlackDot; 

    public Material Black;
    public Material LightGrey;
    public Material White;


    void Awake()
    {

        LDStimX = LeftSmallDiag.transform.position.x;
        RDStimX = RightSmallDiag.transform.position.x;
        LVStimX = LeftSmallVert.transform.position.x;
        RVStimX = RightSmallVert.transform.position.x;


        DiagGreyRWCoord = DiagGreyRW.transform.position;
        DiagGreyLWCoord = DiagGreyLW.transform.position;
        VertGreyRWCoord = VertGreyRW.transform.position;
        VertGreyLWCoord = VertGreyLW.transform.position;

        LeftDiagGratingDisplaced = new Vector3(-50.0f, 2.5f, 9.0f);
        RightDiagGratingDisplaced = new Vector3(50.0f, 2.5f, 9.0f);
        LeftVertGratingDisplaced = new Vector3(-50.0f, 2.5f, 7.5f);
        RightVertGratingDisplaced = new Vector3(50.0f, 2.5f, 7.5f);

        for (int i = 1; i < 11; i++)
        { 

            GameObject DCeilingClone = Instantiate(DiagCeiling) as GameObject;
            GameObject VCeilingClone = Instantiate(VertCeiling) as GameObject;

            DCeilingClone.transform.position = new Vector3(0.0f, 5.0f, i * 50.0f + 25f);
            VCeilingClone.transform.position = new Vector3(20.0f, 5.0f, i * 50.0f + 25f);          

            GameObject VLWClone = Instantiate(VertGreyLW) as GameObject;
            GameObject VRWClone = Instantiate(VertGreyRW) as GameObject;

            VLWClone.transform.position = new Vector3(VertGreyLWCoord.x, VertGreyLWCoord.y, i * 50.0f + VertGreyLWCoord.z);
            VRWClone.transform.position = new Vector3(VertGreyRWCoord.x, VertGreyRWCoord.y, i * 50.0f + VertGreyRWCoord.z);

            GameObject DRWClone = Instantiate(DiagGreyRW) as GameObject;
            GameObject DLWClone = Instantiate(DiagGreyLW) as GameObject;

            DRWClone.transform.position = new Vector3(DiagGreyRWCoord.x, DiagGreyRWCoord.y, i * 50.0f + DiagGreyRWCoord.z);
            DLWClone.transform.position = new Vector3(DiagGreyLWCoord.x, DiagGreyLWCoord.y, i * 50.0f + DiagGreyLWCoord.z);

            GameObject DGrndClone = Instantiate(DiagGround) as GameObject;
            GameObject VGrndClone = Instantiate(VertGround) as GameObject;

            DGrndClone.transform.position = new Vector3(0.0f, -2.0f, i * 100.0f + 10f);
            VGrndClone.transform.position = new Vector3(20.0f, -2.0f, i * 100.0f + 10f);
        }

        for (int i = 1; i < 4; i++)
        {
            GameObject RevDCeilingClone = Instantiate(DiagCeiling) as GameObject;
            GameObject RevVCeilingClone = Instantiate(VertCeiling) as GameObject;

            RevDCeilingClone.transform.position = new Vector3(0.0f, 5.0f, i * -50.0f + 25f);
            RevVCeilingClone.transform.position = new Vector3(20.0f, 5.0f, i * -50.0f + 25f);

            GameObject RevDGrndClone = Instantiate(DiagGround) as GameObject;
            GameObject RevVGrndClone = Instantiate(VertGround) as GameObject;

            RevDGrndClone.transform.position = new Vector3(0.0f, -2.0f, i * -100.0f + 10f);
            RevVGrndClone.transform.position = new Vector3(20.0f, -2.0f, i * -100.0f + 10f);


            GameObject RevVLWClone = Instantiate(VertGreyLW) as GameObject;
            GameObject RevVRWClone = Instantiate(VertGreyRW) as GameObject;

            RevVLWClone.transform.position = new Vector3(VertGreyLWCoord.x, VertGreyLWCoord.y, i * -50.0f + VertGreyLWCoord.z);
            RevVRWClone.transform.position = new Vector3(VertGreyRWCoord.x, VertGreyRWCoord.y, i * -50.0f + VertGreyRWCoord.z);

            GameObject RevDRWClone = Instantiate(DiagGreyRW) as GameObject;
            GameObject RevDLWClone = Instantiate(DiagGreyLW) as GameObject;

            RevDRWClone.transform.position = new Vector3(DiagGreyRWCoord.x, DiagGreyRWCoord.y, i * -50.0f + DiagGreyRWCoord.z);
            RevDLWClone.transform.position = new Vector3(DiagGreyLWCoord.x, DiagGreyLWCoord.y, i * -50.0f + DiagGreyLWCoord.z);

        }

        if (GameMode == GameVersion.BilateralStimDotsTraining)

        {
            LeftDiagGrating.transform.position = new Vector3(-5.0f, 2.5f, 9.0f);
            RightDiagGrating.transform.position = new Vector3(5.0f, 2.5f, 9.0f);
            LeftVertGrating.transform.position = new Vector3(15.0f, 2.5f, 7.5f);
            RightVertGrating.transform.position = new Vector3(25.0f, 2.5f, 7.5f);

            LeftDiagDefault = LeftDiagGrating.transform.position; 
            RightDiagDefault = RightDiagGrating.transform.position;
            LeftVertDefault = LeftVertGrating.transform.position;
            RightVertDefault = RightVertGrating.transform.position;

            for (int i = 0; i < 250; i++)
            {
                DiagRandY = UnityEngine.Random.Range(1.0f, 5.0f);
                DiagRandDot = UnityEngine.Random.value;
                DotI = Convert.ToString(i);

                if (DiagRandDot < 0.5f)
                {
                    GameObject DRWDotClone = Instantiate(WhiteDot) as GameObject;
                    GameObject DLWDotClone = Instantiate(WhiteDot) as GameObject;

                    DRWDotClone.transform.position = new Vector3(-4.98f, DiagRandY, i * 2 + 60);
                    DLWDotClone.transform.position = new Vector3(4.98f, DiagRandY, i * 2 + 60);
                }

                if (DiagRandDot > 0.5f)
                {
                    GameObject DRBDotClone = Instantiate(BlackDot) as GameObject;
                    GameObject DLBDotClone = Instantiate(BlackDot) as GameObject;

                    DRBDotClone.transform.position = new Vector3(-4.98f, DiagRandY, i * 2 + 60);
                    DLBDotClone.transform.position = new Vector3(4.98f, DiagRandY, i * 2 + 60);
                }
            }

            for (int i = 1; i < 250; i++)
            {
                VertRandY = UnityEngine.Random.Range(1.0f, 5.0f);
                VertRandDot = UnityEngine.Random.value;
                DotI = Convert.ToString(i);

                if (VertRandDot < 0.5f)
                {
                    GameObject VRWDotClone = Instantiate(WhiteDot) as GameObject;
                    GameObject VLWDotClone = Instantiate(WhiteDot) as GameObject;

                    VRWDotClone.transform.position = new Vector3(15.02f, VertRandY, i * 2 + 80);
                    VLWDotClone.transform.position = new Vector3(24.98f, VertRandY, i * 2 + 80);
                }

                if (VertRandDot > 0.5f)
                {
                    GameObject VRBDotClone = Instantiate(BlackDot) as GameObject;
                    GameObject VLBDotClone = Instantiate(BlackDot) as GameObject;

                    VRBDotClone.transform.position = new Vector3(15.02f, VertRandY, i * 2 + 80);
                    VLBDotClone.transform.position = new Vector3(24.98f, VertRandY, i * 2 + 80);
                }
            }
        }

        else if (GameMode == GameVersion.BilateralStim)
        {
            LeftDiagGrating.transform.position = new Vector3(-5.0f, 2.5f, 9.0f);
            RightDiagGrating.transform.position = new Vector3(5.0f, 2.5f, 9.0f);
            LeftVertGrating.transform.position = new Vector3(15.0f, 2.5f, 7.5f);
            RightVertGrating.transform.position = new Vector3(25.0f, 2.5f, 7.5f);

            LeftDiagDefault = LeftDiagGrating.transform.position;
            RightDiagDefault = RightDiagGrating.transform.position;
            LeftVertDefault = LeftVertGrating.transform.position;
            RightVertDefault = RightVertGrating.transform.position;
        }

        else
        {
            LeftDiagGrating.transform.position = new Vector3(-50.0f, 2.5f, 9.0f);
            RightDiagGrating.transform.position = new Vector3(50.0f, 2.5f, 9.0f);
            LeftVertGrating.transform.position = new Vector3(-50.0f, 2.5f, 7.5f);
            RightVertGrating.transform.position = new Vector3(50.0f, 2.5f, 7.5f);

        }

        if ((GameMode == GameVersion.LeftCuedDynamic || GameMode == GameVersion.RightCuedDynamic))
        {
            Cued = true; // test to make sure it stays true 
        }



        offset = 15.0f;
        RandReceived = false;
        PrevRandDist = 0;
        TextToSend = "0";
        //smoothing = 1.0f;
        StimTrialCount = 0;
        RelativePosition = 0;
        CueShown = false;
        CueTimer = 0;
        StimTimer = 0;
        Static = false; 
    }       

    void Start()
    {
        Debug.Log("displays connected:" + Display.displays.Length);

        init();
        Application.runInBackground = true;


      
       StimOffset = LeftSmallDiag.transform.position.z - transform.position.z;

            DotCueX = DotCue.transform.position.x;
            CueOffset = DotCue.transform.position.z - transform.position.z;

            DotCue.transform.position = new Vector3(DotCueX, 2.5f, StimOffset);

    }

    public void Activate()
    {
        Screen.fullScreen = true;
    }

    private void init()
    {
        print("UDP.init()");

        ReceivePort = 8888;
        SendPort = 8051;
        SendIP = "169.230.68.193";

        receiveRunning = true;
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();


        sendRunning = true;
        sendThread = new Thread(new ThreadStart(SendData));
        sendThread.IsBackground = true;
        sendThread.Start();
    }


    void Update()
    {
        deltaTime += (Time.deltaTime - deltaTime) * 0.1f;
        fps = 1.0f / deltaTime;

        TextToSend = "0";

        udpIn = lastReceivedUDPPacket;
        stringSize = udpIn.Length;

        if (stringSize > 0)
        {
            ReceivedStim = udpIn.Substring(0, 1);
            ResetSession = udpIn.Substring(1, 1);
            StimIdentity = udpIn.Substring(2, 1);
            RandNum = udpIn.Substring(3, 3);
            PosIn = udpIn.Substring(6, (stringSize - 6));
        }

        int.TryParse(ReceivedStim, out StimReceived);
        //float.TryParse(PosIn, out position);
        //int.TryParse(RandNum, out RandDist);
        int.TryParse(NewTrial, out resetPos);
        int.TryParse(ResetSession, out ResetSesh);

        transform.position += transform.forward * Input.GetAxis("Vertical") * 0.3f;
        position = transform.position.z;
        RightEye.transform.position = transform.position;
        LeftEye.transform.position = transform.position;

        //fracMovt = smoothing * Time.deltaTime;

        //RelativePosition = position - LastPosition;
        RelativePosition = position;
        RCamDistance = RightEye.transform.position.z;
        LCamDistance = LeftEye.transform.position.z;
        //StimDistance = ((float)RandDist);

        //Cam Movement 
        //if (position != LCamDistance)
        //{
        //    transform.position = new Vector3(transform.position.x, transform.position.y, RelativePosition);
        //    RightEye.transform.position = new Vector3(transform.position.x, transform.position.y, RelativePosition);
        //}

        if (RandCreated == false && RelativePosition > 100f)
        {
            RandDist = UnityEngine.Random.Range(130.0f, 160.0f);
            RandStim = UnityEngine.Random.value;
            RandCueSide = UnityEngine.Random.value;
            RandStimVersion = 0.4f; // UnityEngine.Random.value;
            StimDistance = RandDist;
            RandCreated = true;
        }

        if (RandStimVersion < 0.5f && RandStimVersion != 0)
        {
            VariantVersion = true; 
        }
        else
        {
            VariantVersion = false;
        }

        if (StimDistance > 0 && RandDist != PrevRandDist && RandReceived == false && RandCreated == true) // not equal to 
        {
            RandReceived = true;
            PrevRandDist = RandDist;
        }

        if (LCamDistance > 0 && RelativePosition > (StimDistance - 1.0f) && StimDistance > 0)
        {
            PositionReached = true;
        }


        //sets up cueing if cued condition is true 
        if (Cued == true && PositionReached == true && VariantVersion == true && CueStarted == false) 
        {
            CorridorLocation = transform.position.x;

            if (RandCueSide < 0.5f && RandCueSide != 0 && CorridorLocation == 0.0f) //left diag corridor
            {
                DotCue.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + CueOffset);
            }

            if (RandCueSide >= 0.5f && CorridorLocation == 0.0f) //right diag corridor
            {
                DotCue.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + CueOffset);
            }

            if (RandCueSide < 0.5f && RandCueSide != 0 && CorridorLocation == 20.0f) //left vert corridor 
            {
                DotCue.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + CueOffset);
            }

            if (RandCueSide >= 0.5f && CorridorLocation == 20.0f) //right vert corridor 
            {
                DotCue.transform.position = new Vector3(25.0f, 2.5f, RelativePosition + CueOffset);
            }

            CueStarted = true;

        }

        if (CueStarted == true)
        {
            CueTimer += Time.deltaTime;
        }


        if (CueTimer > CueLength)
        {           
            DotCue.transform.position = new Vector3(DotCueX, 2.5f, RelativePosition + CueOffset);          
        }

        if (CueTimer > CueLength + 0.5f)
        {           
            CueShown = true;
        }




        if (GameMode == GameVersion.BilateralStimDotsTraining)

        {
            //bilateral long stim only 
            if (StimIdentity == "D" && PositionReached == true) // && RandReceived == true )
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;

                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;
                //StimStartTime = Timer; 
                RandReceived = false;
                PositionReached = false;
                RandDist = 0;
                LastPosition = position;
                DStimTriggered = true;
            }

            if (StimIdentity == "V" && PositionReached == true) //&& RandReceived == true
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;

                transform.position = new Vector3(20.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(20.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;
                VertTrialCount = VertTrialCount + 1;
                //StimStartTime = Timer; 
                RandReceived = false;
                PositionReached = false;
                RandDist = 0;
                VStimTriggered = true;

            }
        }




        if (GameMode == GameVersion.BilateralStim)
        {

            //bilateral long stim if all other cases are false
            if (RandStim >= 0.5f) // (StimIdentity == "D" && PositionReached == true)
            {

                if (RandStimVersion >= 0.5 && PositionReached == true)
                {
                    Static = true;
                    LeftSmallDiag.transform.position = new Vector3(LDStimX, 2.5f, 0.0f + StimOffset); //RelativePosition + StimOffset);
                    RightSmallDiag.transform.position = new Vector3(RDStimX, 2.5f, 0.0f + StimOffset); //RelativePosition + StimOffset);
                    LeftDiagGrating.transform.position = LeftDiagDefault;
                    RightDiagGrating.transform.position = RightDiagDefault;

                    StimMoved = true;
                }


                //Alternating with Bilateral Small Stim 
                if (SmallStim == true && LeftUnilateral == false && RightUnilateral == false && VariantVersion == true)
                {
                    if (StaticStim == true)
                    {
                        Static = true;
                    }

                    if ((Cued == false && PositionReached == true) || (Cued == true && CueTimer > CueLength && CueShown == true))
                    {
                        LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                        RightDiagGrating.transform.position = RightDiagGratingDisplaced;
                        LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                        RightVertGrating.transform.position = RightVertGratingDisplaced;

                        LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, 0.0f + StimOffset);
                        RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, 0.0f + StimOffset);

                        StimMoved = true;
                        CueShown = false;
                    }
                }


                //Alternating with Long Left Unilateral 
                if (LeftUnilateral == true && SmallStim == false && VariantVersion == true)
                {
                    Static = true; //test

                    if ((Cued == false && PositionReached == true) || (Cued == true && CueTimer > CueLength && CueShown == true))
                    {
                        RightDiagGrating.transform.position = RightDiagGratingDisplaced; //moves right diag out of the way  
                        LeftDiagGrating.transform.position = LeftDiagDefault;
                        StimMoved = true;
                        CueShown = false;
                    }
                }


                //Alternating with Long Right Unilateral
                if (RightUnilateral == true && SmallStim == false && VariantVersion == true)
                {
                    Static = true; //test

                    if ((Cued == false && PositionReached == true) || (Cued == true && CueTimer > CueLength && CueShown == true))
                    {
                        LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                        RightDiagGrating.transform.position = RightDiagDefault;
                        StimMoved = true;
                        CueShown = false;
                    }
                }


                //Alternating with Small Left Unilateral 
                if (LeftUnilateral == true && SmallStim == true && VariantVersion == true)
                {
                    if (StaticStim == true)
                    {
                        Static = true;
                    }

                    if ((Cued == false && PositionReached == true) || (Cued == true && CueTimer > CueLength && CueShown == true))
                    {
                        LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                        RightDiagGrating.transform.position = RightDiagGratingDisplaced;
                        LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                        RightVertGrating.transform.position = RightVertGratingDisplaced;

                        LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, 0.0f + StimOffset);
                        RightSmallDiag.transform.position = new Vector3(RDStimX, 2.5f, 0.0f + StimOffset);                   

                        StimMoved = true;
                        CueShown = false;
                    }
                }



                //Alternating with Small Right Unilateral 
                if (RightUnilateral == true && SmallStim == true && VariantVersion == true)
                {
                    if (StaticStim == true)
                    {
                        Static = true;
                    }

                    if ((Cued == false && PositionReached == true) || (Cued == true && CueTimer > CueLength && CueShown == true))
                    {
                        LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                        RightDiagGrating.transform.position = RightDiagGratingDisplaced;
                        LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                        RightVertGrating.transform.position = RightVertGratingDisplaced;

                        RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, 0.0f + StimOffset);
                        LeftSmallDiag.transform.position = new Vector3(LDStimX, 2.5f, 0.0f + StimOffset);

                        StimMoved = true;
                        CueShown = false;
                    }
                }

                if (StimMoved == true)
                {                  
                        transform.position = new Vector3(0.0f, 0.0f, 0.0f); // RelativePosition);
                        RightEye.transform.position = new Vector3(0.0f, 0.0f, 0.0f); // RelativePosition);
                        LeftEye.transform.position = new Vector3(0.0f, 0.0f, 0.0f);

                        //LastPosition = position;
                        //RelativePosition = position - LastPosition;

                        StimTrialCount = StimTrialCount + 1;

                        LastPosition = position;
                        DStimTriggered = true;
                        RandCreated = false;
                        StimMoved = false;
                        PositionReached = false;
                        CueTimer = 0;
                        CueStarted = false;

                }


                if (Static == false && DStimTriggered == true)
                {
                    StimTimer += Time.deltaTime;
                    MoveDStim = true;
                    
                }


                if (DStimTriggered == true && Static == false && StimTimer > StimPresentationTime)
                {
                    if (SmallStim == true && LeftUnilateral == false && RightUnilateral == false)
                    {
                        LeftSmallDiag.transform.position = new Vector3(LDStimX, 2.5f, 0.0f + StimOffset); //RelativePosition + StimOffset);
                        RightSmallDiag.transform.position = new Vector3(RDStimX, 2.5f, 0.0f + StimOffset); //RelativePosition + StimOffset);
                    }

                    if (LeftUnilateral == true && SmallStim == true)
                    {
                        LeftSmallDiag.transform.position = new Vector3(LDStimX, 2.5f, 0.0f + StimOffset); //RelativePosition + StimOffset);
                    }

                    if (RightUnilateral == true && SmallStim == true)
                    {
                        RightSmallDiag.transform.position = new Vector3(RDStimX, 2.5f, 0.0f + StimOffset); //RelativePosition + StimOffset);
                    }

                    MoveDStim = false;
                    StimStarted = false;
                    DStimTriggered = false;
                    StimTimer = 0;
                    Transported = false;
                    RandReceived = false;
                    RandDist = 0;
                }

                else if (DStimTriggered == true && Static == true)
                {
                    StimStarted = false;
                    DStimTriggered = false;
                    StimTimer = 0;
                    Transported = false;
                    Static = false;
                    RandReceived = false;
                    RandDist = 0;
                }
            }











            if (RandStim < 0.5f) //(StimIdentity == "V"  && PositionReached == true) 
            {



                if (RandStimVersion >= 0.5 && PositionReached == true)
                {
                    Static = true;
                    LeftSmallVert.transform.position = new Vector3(LVStimX, 2.5f, 0.0f + StimOffset); //RelativePosition + StimOffset);
                    RightSmallVert.transform.position = new Vector3(RVStimX, 2.5f, 0.0f + StimOffset); //RelativePosition + StimOffset);
                    LeftVertGrating.transform.position = LeftVertDefault;
                    RightVertGrating.transform.position = RightVertDefault;

                    StimMoved = true;
                }

                //Alternating with Bilateral Small Stim 
                if (SmallStim == true && LeftUnilateral == false && RightUnilateral == false && VariantVersion == true)
                {
                    if (StaticStim == true)
                    {
                        Static = true;
                    }

                    if ((Cued == false && PositionReached == true) || (Cued == true && CueTimer > CueLength && CueShown == true))
                    {
                        LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                        RightDiagGrating.transform.position = RightDiagGratingDisplaced;
                        LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                        RightVertGrating.transform.position = RightVertGratingDisplaced;

                        RightSmallVert.transform.position = new Vector3(25.0f, 2.5f, 0.0f + StimOffset);
                        LeftSmallVert.transform.position = new Vector3(15.0f, 2.5f, 0.0f + StimOffset);

                        StimMoved = true;
                        CueShown = false;
                    }
                }


                //Alternating with Long Left Unilateral 
                if (LeftUnilateral == true && SmallStim == false && VariantVersion == true)
                {
                    Static = true; //test

                    if ((Cued == false && PositionReached == true) || (Cued == true && CueTimer > CueLength && CueShown == true))
                    {
                        RightVertGrating.transform.position = RightVertGratingDisplaced;
                        LeftVertGrating.transform.position = LeftVertDefault;
                        StimMoved = true;
                        CueShown = false;
                    }
                }


                //Alternating with Long Right Unilateral
                if (RightUnilateral == true && SmallStim == false && VariantVersion == true)
                {
                    Static = true; //test

                    if ((Cued == false && PositionReached == true) || (Cued == true && CueTimer > CueLength && CueShown == true))
                    {
                        LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                        RightVertGrating.transform.position = RightVertDefault;
                        StimMoved = true;
                        CueShown = false;
                    }
                }


                //Alternating with Small Left Unilateral 
                if (LeftUnilateral == true && SmallStim == true && VariantVersion == true)
                {
                    if (StaticStim == true)
                    {
                        Static = true;
                    }

                    if ((Cued == false && PositionReached == true) || (Cued == true && CueTimer > CueLength && CueShown == true))
                    {
                        LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                        RightDiagGrating.transform.position = RightDiagGratingDisplaced;
                        LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                        RightVertGrating.transform.position = RightVertGratingDisplaced;

                        LeftSmallVert.transform.position = new Vector3(15.0f, 2.5f, 0.0f + StimOffset);
                        RightSmallVert.transform.position = new Vector3(RVStimX, 2.5f, 0.0f + StimOffset);
                        StimMoved = true;
                        CueShown = false;

                    }
                }


                //Alternating with Small Right Unilateral 
                if (RightUnilateral == true && SmallStim == true && VariantVersion == true)
                {
                    if (StaticStim == true)
                    {
                        Static = true;
                    }

                    if ((Cued == false && PositionReached == true) || (Cued == true && CueTimer > CueLength && CueShown == true))
                    {
                        LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                        RightDiagGrating.transform.position = RightDiagGratingDisplaced;
                        LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                        RightVertGrating.transform.position = RightVertGratingDisplaced;

                        RightSmallVert.transform.position = new Vector3(25.0f, 2.5f, 0.0f + StimOffset);
                        LeftSmallVert.transform.position = new Vector3(LVStimX, 2.5f, 0.0f + StimOffset);
                        StimMoved = true;
                        CueShown = false;
                    }
                }


                //LastPosition = position;
                //RelativePosition = position - LastPosition;

                if (StimMoved == true)
                {
                        transform.position = new Vector3(20.0f, 0.0f, 0.0f);  // RelativePosition);
                        RightEye.transform.position = new Vector3(20.0f, 0.0f, 0.0f); // RelativePosition);
                        LeftEye.transform.position = new Vector3(20.0f, 0.0f, 0.0f); // RelativePosition);

                        StimTrialCount = StimTrialCount + 1;
                        VertTrialCount = VertTrialCount + 1;
                        //StimStartTime = Timer; 

                        StimStarted = true;                       
                        RandCreated = false;
                        VStimTriggered = true;
                        StimMoved = false;
                        PositionReached = false;
                        CueTimer = 0;
                        CueStarted = false;

                }



                if (Static == false && StimStarted == true)
                {
                    StimTimer += Time.deltaTime;
                    MoveVStim = true;                  
                }


                if (VStimTriggered == true && StimTimer > StimPresentationTime)
                {
                    if (SmallStim == true && LeftUnilateral == false && RightUnilateral == false)
                    {
                        LeftSmallVert.transform.position = new Vector3(LVStimX, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);
                        RightSmallVert.transform.position = new Vector3(RVStimX, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);
                    }

                    if (LeftUnilateral == true && SmallStim == true)
                    {
                        LeftSmallVert.transform.position = new Vector3(LVStimX, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);
                    }

                    if (RightUnilateral == true && SmallStim == true)
                    {
                        RightSmallVert.transform.position = new Vector3(RVStimX, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);
                    }

                    MoveVStim = false;
                    StimStarted = false;
                    VStimTriggered = false;
                    StimTimer = 0;
                    RandDist = 0;
                    RandReceived = false;                 
                }

                else if (VStimTriggered == true && Static == true)
                {
                    StimStarted = false;
                    VStimTriggered = false;
                    StimTimer = 0;
                    Transported = false;
                    Static = false;
                    RandDist = 0;
                    RandReceived = false;                
                }

            }
        }
     





        //alternating cued small stim task only 
        if (GameMode == GameVersion.LeftCuedDynamic)
        {
            if (RandStim < 0.5f && RandStim != 0 && CueTimer > CueLength && CueShown == true) //(StimIdentity == "D" && CueTimer > 0.6)
            {

                //LastPosition = position;
                //RelativePosition = position - LastPosition;

                //LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);

                transform.position = new Vector3(0.0f, 0.0f, 0.0f);  // RelativePosition);
                RightEye.transform.position = transform.position;
                LeftEye.transform.position = transform.position;

                LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);

                StimTrialCount = StimTrialCount + 1;

                PositionReached = false;
                DStimTriggered = true;
                StimStarted = true;
                RandCreated = false;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
            }

            if (RandStim >= 0.5f &&  RandStim != 0 && CueTimer > CueLength && CueShown == true)  //(StimIdentity == "V" && CueTimer > 0.6)
            {
                //LeftSmallVert.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);

                //LastPosition = position;
                //RelativePosition = position - LastPosition;

                transform.position = new Vector3(20.0f, 0.0f, 0.0f); //RelativePosition)
                RightEye.transform.position = transform.position;
                LeftEye.transform.position = transform.position;

                LeftSmallVert.transform.position = new Vector3(15.0f, 2.5f, transform.position.z + StimOffset);  //RelativePosition + StimOffset);

                StimTrialCount = StimTrialCount + 1;
                VertTrialCount = VertTrialCount + 1;

                PositionReached = false; 
                VStimTriggered = true;
                StimStarted = true;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
                RandCreated = false;
                RandReceived = false;
                RandDist = 0;

            }

            if (RandStim >= 0.5f && StimStarted == true)
            {
                StimTimer += Time.deltaTime;
                MoveLeftCuedVert = true;
            }

            if (RandStim < 0.5f && RandStim != 0 && StimStarted == true)
            {
                StimTimer += Time.deltaTime;
                MoveLeftCuedDiag = true;
            }


            if (DStimTriggered == true && StimTimer > StimPresentationTime)
            {
                LeftSmallDiag.transform.position = new Vector3(LDStimX, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);              
                StimStarted = false;
                DStimTriggered = false;
                StimTimer = 0;
                MoveLeftCuedDiag = false;
            }

            if (VStimTriggered == true && StimTimer > StimPresentationTime)
            {
                LeftSmallVert.transform.position = new Vector3(LVStimX, 2.5f, transform.position.z + StimOffset); // RelativePosition + StimOffset);
                StimStarted = false;
                VStimTriggered = false;
                StimTimer = 0;
                MoveLeftCuedVert = false;
            }

        }



        if (GameMode == GameVersion.RightCuedDynamic)
        {
            if (RandStim < 0.5f && RandStim != 0 && CueTimer > CueLength && CueShown == true) //(StimIdentity == "D" && CueTimer > 0.6)
            {

                //LastPosition = position;
                //RelativePosition = position - LastPosition;

                //LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);

                transform.position = new Vector3(0.0f, 0.0f, 0.0f);  // RelativePosition);
                RightEye.transform.position = transform.position;
                LeftEye.transform.position = transform.position;

                RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);

                StimTrialCount = StimTrialCount + 1;

                PositionReached = false;
                DStimTriggered = true;
                StimStarted = true;
                RandCreated = false;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
            }

            if (RandStim >= 0.5f && RandStim != 0 && CueTimer > CueLength && CueShown == true)  //(StimIdentity == "V" && CueTimer > 0.6)
            {
                //LeftSmallVert.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);

                //LastPosition = position;
                //RelativePosition = position - LastPosition;

                transform.position = new Vector3(20.0f, 0.0f, 0.0f); //RelativePosition)
                RightEye.transform.position = transform.position;
                LeftEye.transform.position = transform.position;

                RightSmallVert.transform.position = new Vector3(-5.0f, 2.5f, transform.position.z + StimOffset);  //RelativePosition + StimOffset);

                StimTrialCount = StimTrialCount + 1;
                VertTrialCount = VertTrialCount + 1;

                PositionReached = false;
                VStimTriggered = true;
                StimStarted = true;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
                RandCreated = false;
                RandReceived = false;
                RandDist = 0;
            }

            if (RandStim >= 0.5f && StimStarted == true)
            {
                StimTimer += Time.deltaTime;
                MoveRightCuedVert = true;
            }

            if (RandStim < 0.5f && RandStim != 0 && StimStarted == true)
            {
                StimTimer += Time.deltaTime;
                MoveRightCuedDiag = true;
            }


            if (DStimTriggered == true && StimTimer > StimPresentationTime)
            {
                RightSmallDiag.transform.position = new Vector3(RDStimX, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);              
                StimStarted = false;
                DStimTriggered = false;
                StimTimer = 0;
                MoveRightCuedDiag = false;
            }

            if (VStimTriggered == true && StimTimer > StimPresentationTime)
            {
                RightSmallVert.transform.position = new Vector3(RVStimX, 2.5f, transform.position.z + StimOffset); // RelativePosition + StimOffset);
                StimStarted = false;
                VStimTriggered = false;
                StimTimer = 0;
                MoveRightCuedVert = false;
            }

        }



        if (VStimTriggered == true)
        {
            TextToSend = "2";
        }

        if (DStimTriggered == true)
        {
            TextToSend = "1";
        }


        if (StimReceived > 0)
        {
            TextToSend = "0";
            DStimTriggered = false;
            VStimTriggered = false;
        }
    }




    void LateUpdate()
    {

        LCamDistance = transform.position.z;     

        if (CueTimer > 0 && CueTimer < CueLength)
        {
            CurrDotCueX = DotCue.transform.position.x;
            DotCue.transform.position = new Vector3(CurrDotCueX, 2.5f, LCamDistance + StimOffset);
        }

        if (MoveLeftCuedVert == true)
        {
            LeftSmallVert.transform.position = new Vector3(15.0f, 2.5f, LCamDistance + StimOffset);
        }

        if (MoveLeftCuedDiag == true)
        {
            LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
        }

        if (MoveRightCuedVert == true)
        {
            RightSmallVert.transform.position = new Vector3(25.0f, 2.5f, LCamDistance + StimOffset);
        }

        if (MoveRightCuedDiag == true)
        {
            RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
        }


        if (MoveDStim == true)
        {
            if (SmallStim == true && LeftUnilateral == false && RightUnilateral == false)
            {
                LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset); //StimOffset); //RelativePosition + StimOffset);
                RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset); // StimOffset); //RelativePosition + StimOffset);
            }

            if (LeftUnilateral == true && SmallStim == true)
            {
                LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                RightSmallDiag.transform.position = new Vector3(RDStimX, 2.5f, LCamDistance + StimOffset);
                LoopRan = true; 
            }

            if (RightUnilateral == true && SmallStim == true)
            {
                RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset); //RelativePosition + StimOffset);
                LeftSmallDiag.transform.position = new Vector3(LDStimX, 2.5f, LCamDistance + StimOffset);
            }
        }

        if (MoveVStim == true)
        {
            if (SmallStim == true && LeftUnilateral == false && RightUnilateral == false)
            {
                LeftSmallVert.transform.position = new Vector3(15.0f, 2.5f, LCamDistance + StimOffset); //RelativePosition + StimOffset);
                RightSmallVert.transform.position = new Vector3(25.0f, 2.5f, LCamDistance + StimOffset); //RelativePosition + StimOffset);
            }

            if (LeftUnilateral == true && SmallStim == true)
            {
                LeftSmallVert.transform.position = new Vector3(15.0f, 2.5f, LCamDistance + StimOffset); //RelativePosition + StimOffset);
                RightSmallVert.transform.position = new Vector3(RVStimX, 2.5f, LCamDistance + StimOffset);
            }

            if (RightUnilateral == true && SmallStim == true)
            {
                RightSmallVert.transform.position = new Vector3(25.0f, 2.5f, LCamDistance + StimOffset);
                LeftSmallVert.transform.position = new Vector3(LVStimX, 2.5f, LCamDistance + StimOffset); //RelativePosition + StimOffset);
            }
        }



    }

    void FixedUpdate()
    {

        //reset position at start
        if (ResetSesh == 1)
        {
            transform.position = new Vector3(0.0f, 1.0f, 0.0f);
            RightEye.transform.position = new Vector3(0.0f, 1.0f, 0.0f);
            StimDistance = 0;
            RandReceived = false;
            LastPosition = 0; 
            RelativePosition = 0;
            StimIdentity = "O";
            StimTrialCount = 0;
            VertTrialCount = 0;
            TooFar = false; 

        }
    }

    // receive thread 
    private void ReceiveData()
    {
        print("allocating client");
        IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, ReceivePort);
        client = new UdpClient(ReceivePort);
        client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (receiveRunning)
        {
            try
            {
                data = client.Receive(ref anyIP); //byte[] data
                text = Encoding.UTF8.GetString(data);
                // latest UDPpacket
                lastReceivedUDPPacket = text;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    private void SendData()
    {
        print("sending client");
        IPEndPoint SendtoIP = new IPEndPoint(IPAddress.Parse(SendIP), SendPort);
        SendClient = new UdpClient(SendPort);
        SendClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (sendRunning)
        {
            try
            {
                DataToSend = Encoding.UTF8.GetBytes(TextToSend);
                SendClient.Send(DataToSend, DataToSend.Length, SendtoIP);
                lastSentUDPPacket = TextToSend;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    public string getLatestUDPPacket()
    {
        return lastReceivedUDPPacket;
        return lastSentUDPPacket;
    }

    void OnApplicationQuit()
    {
        // stop listening thread
        receiveRunning = false;
        sendRunning = false;
        client.Close();
        SendClient.Close();

        // wait for listening thread to terminate (max. 500ms)		
        receiveThread.Join(500);
        sendThread.Join(500);
    }

}