﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;

public class DShuffleDots : MonoBehaviour {

    private float DiagRandY;
    private float DiagRandDot;
    private string DotI;
    private string FindDotI; 
    private GameObject DRWDotClone;
    private GameObject DLWDotClone;
    private GameObject DRBDotClone;
    private GameObject DLBDotClone;
    private GameObject ShuffleRDot;
    private GameObject ShuffleLDot; 
    public GameObject WhiteDot;
    public GameObject BlackDot;
    public bool Dloop; 
    public int Iteration;
    private float RandSeed;

    public bool loopran; 

    // Use this for initialization

    void Start()
    {
        Iteration = 0; 

        for (int i = 0; i < 250; i++)
        {
            DiagRandY = UnityEngine.Random.Range(1.0f, 5.0f);
            DiagRandDot = UnityEngine.Random.value;
            DotI = Convert.ToString(i);

            if (DiagRandDot < 0.5f)
            {
                GameObject DRWDotClone = Instantiate(WhiteDot) as GameObject;
                GameObject DLWDotClone = Instantiate(WhiteDot) as GameObject;

                DRWDotClone.name = "DRDot" + DotI;
                DLWDotClone.name = "DLDot" + DotI;

                DRWDotClone.transform.position = new Vector3(-4.98f, DiagRandY, i * 2 + 60);
                DLWDotClone.transform.position = new Vector3(4.98f, DiagRandY, i * 2 + 60);
            }

            if (DiagRandDot > 0.5f)
            {
                GameObject DRBDotClone = Instantiate(BlackDot) as GameObject;
                GameObject DLBDotClone = Instantiate(BlackDot) as GameObject;

                DRBDotClone.name = "DRDot" + DotI;
                DLBDotClone.name = "DLDot" + DotI;

                DRBDotClone.transform.position = new Vector3(-4.98f, DiagRandY, i * 2 + 60);
                DLBDotClone.transform.position = new Vector3(4.98f, DiagRandY, i * 2 + 60);
            }
        }

    }
	
	// Update is called once per frame
	void Update ()
    {
     
    }
      
    void OnBecameVisible()
    {
           //UnityEngine.Random.seed = RandSeed;

            for (int i = 0; i < 250; i++)
            {
                DiagRandY = UnityEngine.Random.Range(1.0f, 5.0f);

                FindDotI = Convert.ToString(i);
                ShuffleRDot = GameObject.Find("DRDot" + FindDotI);
                ShuffleLDot = GameObject.Find("DLDot" + FindDotI);

                ShuffleRDot.transform.position = new Vector3(-4.98f, DiagRandY, i * 2 + 60);
                ShuffleLDot.transform.position = new Vector3(4.98f, DiagRandY, i * 2 + 60);
        }

        Iteration = Iteration + 1; 
       
    }

}
