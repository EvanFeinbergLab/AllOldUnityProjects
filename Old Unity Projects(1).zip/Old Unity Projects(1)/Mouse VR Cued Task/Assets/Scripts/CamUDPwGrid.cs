﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.SceneManagement;

public class CamUDPwGrid : MonoBehaviour {

    private Vector3 oldPos;
    private Vector3 newPos;

    private Thread receiveThread;
    // is the script still running
    private bool mRunning;
    // udpclient object
    UdpClient client;
    // UDP port
    public int port;
    // received packet
    private byte[] data;
    private string text;
    private string PosIn;
    private string Stim;
    private string NewTrial;
    public int gridStim;
    private int stringSize;
    private int resetPos;

    public GameObject Ground;

    private float distance; //cam location
    private float position; //UDP position
    private float oldPosition;
    private float smoothing = 1f;
    private float fracMovt;
    private float CloneOrigin;

    private int FwdInstanNum;
    private int RevInstanNum;
    private int InstanLength;
    private int origin;
    // private int numstartclones;
    private int revNum;

    public string lastReceivedUDPPacket = "";
    private string startFwdI;
    private string startRevI;
    private string CloneNum;
    private string nameNum;
    private string PrevCloneNum;
    private string PrevCloneName;
    private string clonename;
    private string iterationString;
    private string udpIn;
    private string PrevCloneI;
    private string OrigCloneName;
    private string StartCloneName;

    public GameObject Grid;
    private GameObject GridClone;
    public Transform GridTarget;
    public Transform GridPoint;

    private bool GridCloneExists;
    private bool GrndCloneExists;

    private float offset;
    private float X;
    private float Y;
    private float targetZ;
    private float InstantCamPos;

    private float camZ;
    private float targetOffset;

    //trying more start clones but shorter 
    // might also try clones the start clone as the cam is approaching
    void Awake()
    {
        for (int i = 1; i < 1001; i++) //originally 200 
        {
            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GroundClone.transform.position = new Vector3(0.0f, 0.0f, i * 50.0f + 5);
        }

        for (int i = 1; i < 100; i++)
        {
            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GroundClone.transform.position = new Vector3(0.0f, 0.0f, i * -50.0f + 5);

        }

        //Grid Control 

        X = GridPoint.transform.position.x;
        Y = GridPoint.transform.position.y;
        targetZ = GridTarget.transform.position.z;
        camZ = transform.position.z;

        offset = GridPoint.transform.position.z - camZ;
        targetOffset = targetZ - camZ;
    }

    //Grid Coroutine
    IEnumerator MoveStim()
    {
        if (GridCloneExists == true)
        {
            GridPoint.transform.position = Vector3.Lerp(GridPoint.transform.position, GridTarget.position, smoothing * Time.deltaTime);
            //edit out above line if you dont want the stimulus to slide 

            GridClone.transform.position = GridPoint.transform.position;
            yield return null;
        }
    }


    void Start()
    {
        init();
    }


    private void init()
    {
        print("UDPSend.init()");

        port = 8888;

        mRunning = true;
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();
    }


    void Update()
    {
        distance = transform.position.z;

        // take the UDP data and extract position
        udpIn = lastReceivedUDPPacket;
        stringSize = udpIn.Length;

        if (stringSize > 0)
        {
            Stim = udpIn.Substring(0, 1);
            NewTrial = udpIn.Substring(1, 1);
            PosIn = udpIn.Substring(2, (stringSize - 2));
        }

        float.TryParse(PosIn, out position);
        int.TryParse(Stim, out gridStim);
        int.TryParse(NewTrial, out resetPos);

        fracMovt = smoothing * Time.deltaTime;

        //Cam Movement 
        if (position < 29999 && position != distance)
        {
            newPos = new Vector3(transform.position.x, transform.position.y, position);
            transform.position = Vector3.Lerp(oldPos, newPos, fracMovt);
        }

        //reset position at start

        if (position == 29999 || Input.GetKeyDown(KeyCode.Return) || resetPos == 1)
        {
            transform.position = new Vector3(0.0f, 1.0f, -1.0f);
        }

        //read out stim info from UDP     

        //if (gridStim > 0)
        // {
        //    GridClone = Instantiate(Grid) as GameObject;
        //    GridClone.transform.position = GridPoint.transform.position;
        //     GridCloneExists = true;
        // }

        //trigger stim with key press
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GridClone = Instantiate(Grid) as GameObject;
            GridClone.transform.position = transform.position;
            GridCloneExists = true;
        }

        if (GridCloneExists == true)
        {
            StartCoroutine("MoveStim");
        }
    }


    void LateUpdate()
    {

        oldPos = transform.position;

        //movement of grid with cam and destruction of grid 
        position = transform.position.z;
        GridTarget.transform.position = new Vector3(GridTarget.transform.position.x, GridTarget.transform.position.y, position + targetOffset);
        GridPoint.transform.position = new Vector3(GridPoint.transform.position.x, GridPoint.transform.position.y, position + offset);

        if (GridCloneExists == true)
        {
            GridClone.transform.position = GridPoint.transform.position;
        }

        if (GridCloneExists == true && GridPoint.transform.position.x >= -3.0f)
        {
            GridClone.SetActive(false);
            GridPoint.transform.position = new Vector3(X, Y, transform.position.z + offset);
        }
    }


    // receive thread 
    private void ReceiveData()
    {
        print("allocating client");
        IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, port);
        client = new UdpClient(port);
        client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (mRunning)
        {
            try
            {
                data = client.Receive(ref anyIP); //byte[] data
                text = Encoding.UTF8.GetString(data);
                // latest UDPpacket
                lastReceivedUDPPacket = text;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    public string getLatestUDPPacket()
    {

        return lastReceivedUDPPacket;
    }

    void OnApplicationQuit()
    {
        // stop listening thread
        mRunning = false;
        client.Close();

        // wait for listening thread to terminate (max. 500ms)		
        receiveThread.Join(500);
    }

}