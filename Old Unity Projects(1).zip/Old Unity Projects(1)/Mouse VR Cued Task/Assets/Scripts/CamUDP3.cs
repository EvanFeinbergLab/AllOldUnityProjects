﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.SceneManagement;

public class CamUDP3 : MonoBehaviour {


    private Vector3 oldPosRCam;
    private Vector3 oldPosLCam;
    private Vector3 newPosRCam;
    private Vector3 newPosLCam;
    private Vector3 GroundCoord;
    private Vector3 CeilingCoord;

    private Thread receiveThread;
    private Thread sendThread; 
    // is the script still running
    private bool receiveRunning;
    private bool sendRunning;
    private int iteration; 

    UdpClient client;
    UdpClient SendClient; 
    // UDP port
    private int SendPort;
    private int ReceivePort; 
    // received packet
    private byte[] data;
    private byte[] DataToSend; 
    private string text;
    private string TextToSend; 
    private string PosIn;
    private string RandNum;
    private string StimTrig;
    private string NewTrial;
    private string itString;
    private string RWCloneName;
    private string LWCloneName;
    private string ReceivedStim;

    private int StimReceived; 
    public int StimTrialCount; 
    public int StimIdentity;
    private int stringSize;
    private int resetPos;
    private int RandDist;

    private float LCamDistance;
    private float position; //UDP position
    private float oldPosition;
    public float smoothing;
    public float fracMovt;
    private float CloneOrigin;
    private float camZ;
    private float WallZ;
    private int DotColor; 

    private int FwdInstanNum;
    private int RevInstanNum;
    private int InstanLength;
    private int origin;

    private int revNum;
    private float PrevRandDist;

    private float offset;
    private float RandY;
    private float RandZ;
    private float RandSize;
    private float RandColor; 

    public string lastReceivedUDPPacket = "";
    public string lastSentUDPPacket = "";
    private string CloneNum;
    private string udpIn;
    private string udpOut; 
    private string LCloneName;
    private string RCloneName;
    private string FWallCloneNum;
    private string BWallCloneNum;
    private string StimWindow;


    public GameObject Dot;
    private GameObject RightDotClone;
    private GameObject LeftDotClone;
    public GameObject LeftEye;
    public GameObject RightEye;
    public GameObject Ceiling;
    private GameObject CeilingClone; 
    public GameObject Ground;
    public GameObject LeftWall;
    private GameObject LWClone;
    public GameObject RightWall;
    private GameObject RWClone;
    public GameObject DiagLW;
    public GameObject DiagRW;
    public GameObject VertLW;
    public GameObject VertRW;
    private GameObject LeftGreyClone;
    private GameObject RightGreyClone;
    private string Task;
    private string SendIP;
    private string FindCloneNum;
    private string FindLWCloneName;
    private string FindRWCloneName;
    private float StimDistance; 

    public AudioSource Lcrinkle;
    public AudioSource Rcrinkle;

    public Material Black;
    public Material LightGrey;
    public Material White; 

    private bool DiagCloneExists;
    private bool VertCloneExists;
    private bool RandReceived;
    private bool PositionReached;

    //trying more start clones but shorter 
    // might also try clones the start clone as the cam is approaching
    void Awake()
    {
        GroundCoord = Ground.transform.position;
        CeilingCoord = Ceiling.transform.position; 

        for (int i = 1; i < 1001; i++)
        {
            FWallCloneNum = Convert.ToString(i);

            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GameObject LWClone = Instantiate(LeftWall) as GameObject;
            GameObject RWClone = Instantiate(RightWall) as GameObject;
            GameObject CeilingClone = Instantiate(Ceiling) as GameObject;
            LWClone.name = "LWallClone" + FWallCloneNum;
            RWClone.name = "RWallClone" + FWallCloneNum;

            GroundClone.transform.position = new Vector3(GroundCoord.x, GroundCoord.y, i * 50.0f + 5f);
            LWClone.transform.position = new Vector3(-4.99f, 2.5f, i * 50.0f + 5f);
            RWClone.transform.position = new Vector3(4.99f, 2.5f, i * 50.0f + 5f);
            CeilingClone.transform.position = new Vector3(CeilingCoord.x, CeilingCoord.y, i * 25.0f);

        }

        for (int i = 1; i < 100; i++)
        {
            GameObject GroundClone = Instantiate(Ground) as GameObject;
            GameObject LWClone = Instantiate(LeftWall) as GameObject;
            GameObject RWClone = Instantiate(RightWall) as GameObject;
            GameObject CeilingClone = Instantiate(Ceiling) as GameObject;
            GroundClone.transform.position = new Vector3(GroundCoord.x, GroundCoord.y, i * -50.0f + 5f);
            LWClone.transform.position = new Vector3(-4.99f, 2.5f, i * -50.0f + 5.1f);
            RWClone.transform.position = new Vector3(4.99f, 2.5f, i * -50.0f + 5.1f);
            CeilingClone.transform.position = new Vector3(CeilingCoord.x, CeilingCoord.y, i * -25.0f);
        }

        for (int i = 1; i < 25025; i++)
        {
            GameObject RightDotClone = Instantiate(Dot) as GameObject;
            GameObject LeftDotClone = Instantiate(Dot) as GameObject;

            RandY = UnityEngine.Random.Range(1.0f, 4.0f);
            RandZ = UnityEngine.Random.Range((i - 1) * 2, i * 2);
            RandSize = UnityEngine.Random.Range(0.3f, 2.0f);

            LeftDotClone.transform.localScale = new Vector3(0.01f, RandSize, RandSize);
            RightDotClone.transform.localScale = new Vector3(0.01f, RandSize, RandSize);

            LeftDotClone.transform.position = new Vector3(-4.98f, RandY, i * 2);
            RightDotClone.transform.position = new Vector3(4.98f, RandY, i * 2);

            RandColor = UnityEngine.Random.Range(1.5f, 3.49f);
            DotColor = (int)RandColor;

            if (DotColor == 1)
            {
                LeftDotClone.GetComponent<Renderer>().material = White;
                RightDotClone.GetComponent<Renderer>().material = White;
            }

            if (DotColor == 2)
            {
                LeftDotClone.GetComponent<Renderer>().material = LightGrey;
                RightDotClone.GetComponent<Renderer>().material = LightGrey;
            }

            if (DotColor == 3)
            {
                LeftDotClone.GetComponent<Renderer>().material = Black;
                RightDotClone.GetComponent<Renderer>().material = Black;
            }

            offset = 15.0f;
            RandReceived = false;
            PrevRandDist = 0;
            TextToSend = "0";
            //smoothing = 2f;
            StimTrialCount = 0;
        }
    }


    void Start()
    {
        Debug.Log("displays connected:" + Display.displays.Length);
        //Display.displays[0] is the primary default display which is always ON 
        //Check is additional displays are available and activate each 

        init(); 
        Application.runInBackground = true;

       
    }

    public void Activate()
    {
        Screen.fullScreen = true;
        //RightEye.fullScreen = true;
    }

    private void init()
    {
        print("UDP.init()");

        ReceivePort = 8888;
        SendPort = 8051;
        SendIP = "169.230.68.193"; 

        receiveRunning = true;
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();


        sendRunning = true; 
        sendThread = new Thread(new ThreadStart(SendData));
        sendThread.IsBackground = true;
        sendThread.Start();
    }


    void Update()
    {
        TextToSend = "0"; 
        //Timer += Time.deltaTime;

        // take the UDP data and extract new trial, stim info (distance trigger & H vs. V), and cam position
        udpIn = lastReceivedUDPPacket;
        stringSize = udpIn.Length;

        if (stringSize > 0)
        {
            ReceivedStim = udpIn.Substring(0, 1);
            NewTrial = udpIn.Substring(1, 1);
            StimTrig = udpIn.Substring(2, 1); 
            RandNum = udpIn.Substring(3, 5);
            PosIn = udpIn.Substring(8, (stringSize - 8));
        }

        int.TryParse(ReceivedStim, out StimReceived);
        float.TryParse(PosIn, out position);
        int.TryParse(StimTrig, out StimIdentity);
        int.TryParse(RandNum, out RandDist);
        int.TryParse(NewTrial, out resetPos);


        fracMovt = smoothing * Time.deltaTime;
        //fracMovt = 1.0f;

        LCamDistance = transform.position.z;
        StimDistance = (float)RandDist; 

        //Cam Movement 
        if (position < 29999 && position != LCamDistance)
        {
            newPosLCam = new Vector3(transform.position.x, transform.position.y, position);
            newPosRCam = new Vector3(RightEye.transform.position.x, RightEye.transform.position.y, position);
            transform.position = Vector3.Lerp(oldPosLCam, newPosLCam, fracMovt);
            RightEye.transform.position = Vector3.Lerp(oldPosRCam, newPosRCam, fracMovt);
        }

        if (StimDistance > 0 && RandDist != PrevRandDist && RandReceived == false) // not equal to 
        {        
            RandReceived = true;
            PrevRandDist = RandDist;                
        }

        if (LCamDistance > 0 && LCamDistance > (StimDistance - 1.0f) && StimDistance > 0)
        {
            PositionReached = true; 
        }

        if (StimIdentity == 1 && RandReceived == true && PositionReached == true)
        {
            CloneNum = Convert.ToString(iteration);

            GameObject DiagLWClone = Instantiate(DiagLW) as GameObject;
            LWCloneName = "LWClone" + CloneNum;
            DiagLWClone.name = LWCloneName;

            GameObject DiagRWClone = Instantiate(DiagRW) as GameObject;
            RWCloneName = "RWClone" + CloneNum;
            DiagRWClone.name = RWCloneName;

            DiagLWClone.transform.position = new Vector3(-4.945f, 2.5f, position + offset);
            DiagRWClone.transform.position = new Vector3(4.945f, 2.5f, position + offset);

            StimTrialCount = StimTrialCount + 1; 
            //StimStartTime = Timer; 
            RandReceived = false;
            PositionReached = false;
            DiagCloneExists = true;
        }

        if (DiagCloneExists == true && StimReceived == 0)
        {
            TextToSend = "1";
        }

        if (DiagCloneExists == true && StimReceived > 0)
        {
            TextToSend = "0";
            DiagCloneExists = false; 
        }

        if (StimIdentity == 2 && RandReceived == true && PositionReached == true)
        {
            CloneNum = Convert.ToString(iteration);

            GameObject VertLWClone = Instantiate(VertLW) as GameObject;
            LWCloneName = "LWClone" + CloneNum;
            VertLWClone.name = LWCloneName;

            GameObject VertRWClone = Instantiate(VertRW) as GameObject;
            RWCloneName = "RWClone" + CloneNum;
            VertRWClone.name = RWCloneName;

            VertLWClone.transform.position = new Vector3(-4.9f, 2.5f, position + offset);
            VertRWClone.transform.position = new Vector3(4.9f, 2.5f, position + offset);
         
            StimTrialCount = StimTrialCount + 1;
            //StimStartTime = Timer; 
            RandReceived = false;
            PositionReached = false;
            VertCloneExists = true;

        }

        if (VertCloneExists == true && StimReceived == 0)
        {
            TextToSend = "2";
        }

        if (VertCloneExists == true && StimReceived > 0)
        {
            TextToSend = "0";
            VertCloneExists = false;
        }

        //Move Stim Clone with cam and Inactivate clone after period of time 

        //if ((Timer - StimStartTime) > StimDuration && (Timer - StimStartTime) < (StimDuration + 1.0f))
        //{
        //  StimTimeOut = true;
        //  StimDistance = 0;
        // }
        // else
        // {
        //     StimTimeOut = false; 
        // }

        // if (HorizCloneExists == true)
        // {
        //    camZ = transform.position.z;

        //     FindCloneNum = Convert.ToString(iteration);
        //     FindLWCloneName = "LWClone" + FindCloneNum; 
        //    FindRWCloneName = "RWClone" + FindCloneNum;

        //    GameObject MoveRClone = GameObject.Find(FindRWCloneName);
        //    GameObject MoveLClone = GameObject.Find(FindLWCloneName);

        //   MoveLClone.transform.position = new Vector3(-4.9f, 2.5f, camZ + offset);
        //   MoveRClone.transform.position = new Vector3(4.9f, 2.5f, camZ + offset);
        // }

        // if (HorizCloneExists == true) // && StimTimeOut == true)
        // {
        //    FindCloneNum = Convert.ToString(iteration);
        //    FindLWCloneName = "LWClone" + FindCloneNum;
        //    FindRWCloneName = "RWClone" + FindCloneNum;

        //    GameObject DestroyRClone = GameObject.Find(FindRWCloneName);
        //    GameObject DestroyLClone = GameObject.Find(FindLWCloneName);

        // Destroy(DestroyLClone);
        //Destroy(DestroyRClone);
        //    DestroyLClone.SetActive(false);
        //    DestroyRClone.SetActive(false);
        //    HorizCloneExists = false;
        //    StimTimeOut = false;
        //    iteration = iteration + 1;
        // }

        // if (VertCloneExists == true)
        // {
        //     camZ = transform.position.z;

        //    FindCloneNum = Convert.ToString(iteration);
        //     FindLWCloneName = "LWClone" + FindCloneNum;
        //    FindRWCloneName = "RWClone" + FindCloneNum;

        //    GameObject MoveRClone = GameObject.Find(FindRWCloneName);
        //    GameObject MoveLClone = GameObject.Find(FindLWCloneName);

        //    MoveLClone.transform.position = new Vector3(-4.9f, 2.5f, camZ + offset);
        //    MoveRClone.transform.position = new Vector3(4.9f, 2.5f, camZ + offset);
        // }


        //if (VertCloneExists == true && StimTimeOut == true)
        //{
        //  FindCloneNum = Convert.ToString(iteration);
        //  FindLWCloneName = "LWClone" + FindCloneNum;
        //  FindRWCloneName = "RWClone" + FindCloneNum;

        // GameObject DestroyRClone = GameObject.Find(FindLWCloneName);
        //   GameObject DestroyLClone = GameObject.Find(FindRWCloneName);

        //   DestroyLClone.SetActive(false);
        //   DestroyRClone.SetActive(false);
        //   VertCloneExists = false;
        //   StimTimeOut = false;
        //   iteration = iteration + 1;
        // }

        if (lastSentUDPPacket == "1" || lastSentUDPPacket == "2")
        {
            TextToSend = "0"; 
        }

    }


    void LateUpdate()
    {
        oldPosLCam = transform.position;
        oldPosRCam = RightEye.transform.position;

        // move audio with camera 
        //camZ = transform.position.z;
        //Rcrinkle.transform.position = new Vector3(0.0f, 10.0f, camZ);
        //Lcrinkle.transform.position = new Vector3(0.0f, 10.0f, camZ);

        if (position == 29999 || resetPos == 1)      
        {
            for (int i = 1; i < (iteration + 1); i++)
            {
                itString = Convert.ToString(i);
                RCloneName = "RWClone" + itString;
                LCloneName = "LWClone" + itString;

                GameObject DestroyLClones = GameObject.Find(RCloneName);
                GameObject DestroyRClones = GameObject.Find(LCloneName);

                Destroy(DestroyLClones);
                Destroy(DestroyRClones);
            }
        }
    }

    void FixedUpdate()
    {
        //reset position at start
        if (position == 29999 || resetPos == 1)
        {
            transform.position = new Vector3(0.0f, 1.0f, 0.0f);
            RightEye.transform.position = new Vector3(0.0f, 1.0f, 0.0f);
            StimDistance = 0; 
            StimIdentity = 0;
            RandReceived = false;               
                   
        }

        if (Input.GetKeyDown(KeyCode.L)) // change to input from UDP 
        {
            Lcrinkle.Play();
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            Rcrinkle.Play();
        }

    }


    // receive thread 
    private void ReceiveData()
    {
        print("allocating client");
        IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, ReceivePort);
        client = new UdpClient(ReceivePort);
        client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (receiveRunning)
        {
            try
            {
                data = client.Receive(ref anyIP); //byte[] data
                text = Encoding.UTF8.GetString(data);
                // latest UDPpacket
                lastReceivedUDPPacket = text;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    private void SendData()
    {
        print("sending client");
        IPEndPoint SendtoIP = new IPEndPoint(IPAddress.Parse(SendIP), SendPort);
        SendClient = new UdpClient(SendPort);
        SendClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (sendRunning)
        {
            try
            {
               DataToSend = Encoding.UTF8.GetBytes(TextToSend);
               SendClient.Send(DataToSend, DataToSend.Length, SendtoIP);
               lastSentUDPPacket = TextToSend;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    public string getLatestUDPPacket()
    {
        return lastReceivedUDPPacket;
    }

    void OnApplicationQuit()
    {
        // stop listening thread
        receiveRunning = false;
        sendRunning = false; 
        client.Close();
        SendClient.Close(); 

        // wait for listening thread to terminate (max. 500ms)		
        receiveThread.Join(500);
        sendThread.Join(500);
    }

}