﻿using UnityEngine;
using System.Collections;

public class GridCtrl : MonoBehaviour
{

    
    private float offset;

    public GameObject Grid;
    private GameObject GridClone;
    public Transform GridTarget;

    public float smoothing = 1f;

    public bool CloneExists; 

    private float X; 
    private float Y;
    private float targetZ;
    private float camZ;
    private float currCamZ;
    private float targetOffset;

    void Awake()
    {
        X = transform.position.x;
        Y = transform.position.y;
        targetZ = GridTarget.transform.position.z;
        camZ = GameObject.Find("Camera").transform.position.z; 

        offset = transform.position.z - camZ;
        targetOffset = targetZ - camZ;      
    }

    IEnumerator MoveStim()
    {        
        if (CloneExists == true)
        {
            transform.position = Vector3.Lerp(transform.position, GridTarget.position, smoothing * Time.deltaTime);
            //edit out above line if you dont want the stimulus to slide 

            GridClone.transform.position = transform.position;
            yield return null;
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GridClone = Instantiate(Grid) as GameObject;
            GridClone.transform.position = transform.position;
            CloneExists = true; 
        }
      
        if (CloneExists == true)
        { 
            StartCoroutine("MoveStim");
        }
    }

        void LateUpdate()
      {
        currCamZ = GameObject.Find("Camera").transform.position.z;
        GridTarget.transform.position = new Vector3(GridTarget.transform.position.x, GridTarget.transform.position.y, currCamZ + targetOffset);
        transform.position = new Vector3(transform.position.x, transform.position.y, currCamZ + offset);

        if (CloneExists == true)
        {           
            GridClone.transform.position = transform.position;
        }      

        if (CloneExists == true && transform.position.x >= -3.0f)
         {
             GridClone.SetActive(false);
             transform.position = new Vector3(X, Y, GameObject.Find("Camera").transform.position.z + offset);
         }
      }
 }