﻿using UnityEngine;
using System.Collections;

public class GridClone : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void FixedUpdate () {

        float moveHorizontal = Input.GetAxis("Horizontal");
        transform.position = transform.position + new Vector3(moveHorizontal, 0.0f, 0.0f);

        if (transform.position.x >= -3.0f)
        {
            DestroyObject(GameObject.Find("Grid(Clone)"));
        }
    }
}
