﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class OtherMaster : MonoBehaviour {

    public enum GameVersion
    {
        BilateralStimDotsTraining,
        BilateralStim,
        LeftCued,
        RightCued
    };

    public GameVersion GameMode;
    public bool LeftUnilateral;
    public bool RightUnilateral;
    public bool SmallStim;
    public bool Cued;
    public bool StaticStim;

    public float StimPresentationTime;


    private Vector3 GroundCoord;
    private Vector3 CeilingCoord;
    private Vector3 DiagGreyRWCoord;
    private Vector3 DiagGreyLWCoord;
    private Vector3 VertGreyRWCoord;
    private Vector3 VertGreyLWCoord;
    private Vector3 NewPosition;

    private Vector3 Location;
    public float RandStim;

    UdpClient client;
    UdpClient SendClient;
    private Thread receiveThread;
    private Thread sendThread;

    private bool receiveRunning;
    private bool sendRunning;
    private bool Reset;
    private bool DTransported;
    private bool VTransported;
    private bool RandReceived;
    private bool PositionReached;
    private bool DiagCloneAppeared;
    private bool VertCloneAppeared;
    private bool DStimTriggered;
    private bool VStimTriggered;
    private bool TooFar;
    private bool CueStarted;
    private bool StimStarted;
    private bool RandCreated;
    private bool CueShown;

    private int ResetSesh;
    private int StimReceived;
    private int stringSize;
    private int resetPos;
    //private int RandDist;
    private float RandDist;

    private int FwdInstanNum;
    private int RevInstanNum;
    private int InstanLength;
    private int origin;

    private int revNum;

    private int SendPort;
    private int ReceivePort;
    private byte[] data;
    private byte[] DataToSend;

    private string text;
    private string TextToSend;
    private string PosIn;
    private string RandNum;
    private string StimTrig;
    private string NewTrial;
    private string itString;
    private string RWCloneName;
    private string LWCloneName;
    private string ReceivedStim;
    private string ResetSession;

    private string CloneNum;
    private string udpIn;
    private string udpOut;
    private string LCloneName;
    private string RCloneName;
    private string FWallCloneNum;
    private string BWallCloneNum;
    private string StimWindow;
    private string Task;
    private string SendIP;
    private string FindCloneNum;
    private string FindLWCloneName;
    private string FindRWCloneName;
    private string DotI;
    private string FindDotI;

    private float[] VertYCoords;
    private float[] DiagYCoords;
    private float DiagRandZ;
    private float LastPosition;
    private float deltaTime;
    private float CueTimer;
    private float StimTimer;
    private float LDStimX;
    private float LVStimX;
    private float RDStimX;
    private float RVStimX;
    private float CorridorLocation;

    private float RCamDistance; //cam location
    private float LCamDistance;
    private float position; //UDP position
    private float smoothing;
    private float fracMovt;

    private float PrevRandDist;
    private float offset;
    private float StimOffset;
    private float RandDot;

    private float DiagRandY;
    private float VertRandY;
    private float VRandY;
    private float DRandY;
    private float VertRandDot;
    private float DiagRandDot;
    private float DotCueX;
    private float CurrDotCueX;
    private float RandCueSide;
    private float RandStimVersion;

    private GameObject DRBDotClone;
    private GameObject DLBDotClone;
    private GameObject DRWDotClone;
    private GameObject DLWDotClone;
    private GameObject VRBDotClone;
    private GameObject VLBDotClone;
    private GameObject VRWDotClone;
    private GameObject VLWDotClone;
    private GameObject DShuffleRDot;
    private GameObject DShuffleLDot;
    private GameObject VShuffleRDot;
    private GameObject VShuffleLDot;
    private GameObject WhiteDotClone;
    private GameObject BlackDotClone;

    private GameObject DCeilingClone;
    private GameObject VCeilingClone;
    private GameObject RevDCeilingClone;
    private GameObject RevVCeilingClone;

    private GameObject DGrndClone;
    private GameObject VGrndClone;
    private GameObject RevDGrndClone;
    private GameObject RevVGrndClone;
    private GameObject DRWClone;
    private GameObject DLWClone;
    private GameObject VRWClone;
    private GameObject VLWClone;

    //public AudioSource Lcrinkle;
    // public AudioSource Rcrinkle;

    public string lastReceivedUDPPacket = "";
    public string lastSentUDPPacket = "";

    public int StimTrialCount;
    public int VertTrialCount;
    public string StimIdentity;
    public float RelativePosition;

    public float StimDistance;
    public float fps;

    public GameObject DotCue;
    public GameObject LeftDiagGrating;
    public GameObject RightDiagGrating;
    public GameObject LeftVertGrating;
    public GameObject RightVertGrating;
    public GameObject LeftSmallDiag;
    public GameObject RightSmallDiag;
    public GameObject LeftSmallVert;
    public GameObject RightSmallVert;


    public GameObject LeftEye;
    public GameObject RightEye;
    public GameObject DiagCeiling;
    public GameObject VertCeiling;
    public GameObject DiagGreyRW;
    public GameObject DiagGreyLW;
    public GameObject VertGreyRW;
    public GameObject VertGreyLW;
    public GameObject DiagGround;
    public GameObject VertGround;
    public GameObject WhiteDot;
    public GameObject BlackDot;

    public Material Black;
    public Material LightGrey;
    public Material White;


    void Awake()
    {

        LDStimX = LeftSmallDiag.transform.position.x;
        RDStimX = RightSmallDiag.transform.position.x;
        LVStimX = LeftSmallVert.transform.position.x;
        RVStimX = RightSmallVert.transform.position.x;


        DiagGreyRWCoord = DiagGreyRW.transform.position;
        DiagGreyLWCoord = DiagGreyLW.transform.position;
        VertGreyRWCoord = VertGreyRW.transform.position;
        VertGreyLWCoord = VertGreyLW.transform.position;

        for (int i = 1; i < 11; i++)
        {

            GameObject DCeilingClone = Instantiate(DiagCeiling) as GameObject;
            GameObject VCeilingClone = Instantiate(VertCeiling) as GameObject;

            DCeilingClone.transform.position = new Vector3(0.0f, 5.0f, i * 50.0f + 25f);
            VCeilingClone.transform.position = new Vector3(20.0f, 5.0f, i * 50.0f + 25f);

            GameObject VLWClone = Instantiate(VertGreyLW) as GameObject;
            GameObject VRWClone = Instantiate(VertGreyRW) as GameObject;

            VLWClone.transform.position = new Vector3(VertGreyLWCoord.x, VertGreyLWCoord.y, i * 50.0f + VertGreyLWCoord.z);
            VRWClone.transform.position = new Vector3(VertGreyRWCoord.x, VertGreyRWCoord.y, i * 50.0f + VertGreyRWCoord.z);

            GameObject DRWClone = Instantiate(DiagGreyRW) as GameObject;
            GameObject DLWClone = Instantiate(DiagGreyLW) as GameObject;

            DRWClone.transform.position = new Vector3(DiagGreyRWCoord.x, DiagGreyRWCoord.y, i * 50.0f + DiagGreyRWCoord.z);
            DLWClone.transform.position = new Vector3(DiagGreyLWCoord.x, DiagGreyLWCoord.y, i * 50.0f + DiagGreyLWCoord.z);

            GameObject DGrndClone = Instantiate(DiagGround) as GameObject;
            GameObject VGrndClone = Instantiate(VertGround) as GameObject;

            DGrndClone.transform.position = new Vector3(0.0f, -2.0f, i * 100.0f + 10f);
            VGrndClone.transform.position = new Vector3(20.0f, -2.0f, i * 100.0f + 10f);
        }

        for (int i = 1; i < 4; i++)
        {
            GameObject RevDCeilingClone = Instantiate(DiagCeiling) as GameObject;
            GameObject RevVCeilingClone = Instantiate(VertCeiling) as GameObject;

            RevDCeilingClone.transform.position = new Vector3(0.0f, 5.0f, i * -50.0f + 25f);
            RevVCeilingClone.transform.position = new Vector3(20.0f, 5.0f, i * -50.0f + 25f);

            GameObject RevDGrndClone = Instantiate(DiagGround) as GameObject;
            GameObject RevVGrndClone = Instantiate(VertGround) as GameObject;

            RevDGrndClone.transform.position = new Vector3(0.0f, -2.0f, i * -100.0f + 10f);
            RevVGrndClone.transform.position = new Vector3(20.0f, -2.0f, i * -100.0f + 10f);


            GameObject RevVLWClone = Instantiate(VertGreyLW) as GameObject;
            GameObject RevVRWClone = Instantiate(VertGreyRW) as GameObject;

            RevVLWClone.transform.position = new Vector3(VertGreyLWCoord.x, VertGreyLWCoord.y, i * -50.0f + VertGreyLWCoord.z);
            RevVRWClone.transform.position = new Vector3(VertGreyRWCoord.x, VertGreyRWCoord.y, i * -50.0f + VertGreyRWCoord.z);

            GameObject RevDRWClone = Instantiate(DiagGreyRW) as GameObject;
            GameObject RevDLWClone = Instantiate(DiagGreyLW) as GameObject;

            RevDRWClone.transform.position = new Vector3(DiagGreyRWCoord.x, DiagGreyRWCoord.y, i * -50.0f + DiagGreyRWCoord.z);
            RevDLWClone.transform.position = new Vector3(DiagGreyLWCoord.x, DiagGreyLWCoord.y, i * -50.0f + DiagGreyLWCoord.z);

        }

        if (GameMode == GameVersion.BilateralStimDotsTraining)

        {
            LeftDiagGrating.transform.position = new Vector3(-5.0f, 2.5f, 9.0f);
            RightDiagGrating.transform.position = new Vector3(5.0f, 2.5f, 9.0f);
            LeftVertGrating.transform.position = new Vector3(15.0f, 2.5f, 7.5f);
            RightVertGrating.transform.position = new Vector3(25.0f, 2.5f, 7.5f);

            for (int i = 0; i < 250; i++)
            {
                DiagRandY = UnityEngine.Random.Range(1.0f, 5.0f);
                DiagRandDot = UnityEngine.Random.value;
                DotI = Convert.ToString(i);

                if (DiagRandDot < 0.5f)
                {
                    GameObject DRWDotClone = Instantiate(WhiteDot) as GameObject;
                    GameObject DLWDotClone = Instantiate(WhiteDot) as GameObject;

                    DRWDotClone.transform.position = new Vector3(-4.98f, DiagRandY, i * 2 + 60);
                    DLWDotClone.transform.position = new Vector3(4.98f, DiagRandY, i * 2 + 60);
                }

                if (DiagRandDot > 0.5f)
                {
                    GameObject DRBDotClone = Instantiate(BlackDot) as GameObject;
                    GameObject DLBDotClone = Instantiate(BlackDot) as GameObject;

                    DRBDotClone.transform.position = new Vector3(-4.98f, DiagRandY, i * 2 + 60);
                    DLBDotClone.transform.position = new Vector3(4.98f, DiagRandY, i * 2 + 60);
                }
            }

            for (int i = 1; i < 250; i++)
            {
                VertRandY = UnityEngine.Random.Range(1.0f, 5.0f);
                VertRandDot = UnityEngine.Random.value;
                DotI = Convert.ToString(i);

                if (VertRandDot < 0.5f)
                {
                    GameObject VRWDotClone = Instantiate(WhiteDot) as GameObject;
                    GameObject VLWDotClone = Instantiate(WhiteDot) as GameObject;

                    VRWDotClone.transform.position = new Vector3(15.02f, VertRandY, i * 2 + 80);
                    VLWDotClone.transform.position = new Vector3(24.98f, VertRandY, i * 2 + 80);
                }

                if (VertRandDot > 0.5f)
                {
                    GameObject VRBDotClone = Instantiate(BlackDot) as GameObject;
                    GameObject VLBDotClone = Instantiate(BlackDot) as GameObject;

                    VRBDotClone.transform.position = new Vector3(15.02f, VertRandY, i * 2 + 80);
                    VLBDotClone.transform.position = new Vector3(24.98f, VertRandY, i * 2 + 80);
                }
            }
        }

        else
        {
            LeftDiagGrating.transform.position = new Vector3(-50.0f, 2.5f, 9.0f);
            RightDiagGrating.transform.position = new Vector3(50.0f, 2.5f, 9.0f);
            LeftVertGrating.transform.position = new Vector3(-50.0f, 2.5f, 7.5f);
            RightVertGrating.transform.position = new Vector3(50.0f, 2.5f, 7.5f);

        }



        offset = 15.0f;
        RandReceived = false;
        PrevRandDist = 0;
        TextToSend = "0";
        //smoothing = 1.0f;
        StimTrialCount = 0;
        RelativePosition = 0;
        CueShown = false;
    }

    void Start()
    {
        Debug.Log("displays connected:" + Display.displays.Length);

        init();
        Application.runInBackground = true;

        if (GameMode == GameVersion.LeftCued || GameMode == GameVersion.RightCued || Cued == true)

        {
            DotCueX = DotCue.transform.position.x;
            StimOffset = DotCue.transform.position.z - transform.position.z;

            DotCue.transform.position = new Vector3(DotCueX, 2.5f, StimOffset);

        }

    }

    public void Activate()
    {
        Screen.fullScreen = true;
    }

    private void init()
    {
        print("UDP.init()");

        ReceivePort = 8888;
        SendPort = 8051;
        SendIP = "169.230.68.193";

        receiveRunning = true;
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();


        sendRunning = true;
        sendThread = new Thread(new ThreadStart(SendData));
        sendThread.IsBackground = true;
        sendThread.Start();
    }


    void Update()
    {
        deltaTime += (Time.deltaTime - deltaTime) * 0.1f;
        fps = 1.0f / deltaTime;

        TextToSend = "0";

        udpIn = lastReceivedUDPPacket;
        stringSize = udpIn.Length;

        if (stringSize > 0)
        {
            ReceivedStim = udpIn.Substring(0, 1);
            ResetSession = udpIn.Substring(1, 1);
            StimIdentity = udpIn.Substring(2, 1);
            RandNum = udpIn.Substring(3, 3);
            PosIn = udpIn.Substring(6, (stringSize - 6));
        }

        int.TryParse(ReceivedStim, out StimReceived);
        //float.TryParse(PosIn, out position);
        //int.TryParse(RandNum, out RandDist);
        int.TryParse(NewTrial, out resetPos);
        int.TryParse(ResetSession, out ResetSesh);

        transform.position += transform.forward * Input.GetAxis("Vertical") * 0.3f;
        position = transform.position.z;
        RightEye.transform.position = transform.position;
        LeftEye.transform.position = transform.position;

        //fracMovt = smoothing * Time.deltaTime;

        //RelativePosition = position - LastPosition;
        RelativePosition = position;
        RCamDistance = RightEye.transform.position.z;
        LCamDistance = LeftEye.transform.position.z;
        //StimDistance = ((float)RandDist);

        //Cam Movement 
        //if (position != LCamDistance)
        //{
        //    transform.position = new Vector3(transform.position.x, transform.position.y, RelativePosition);
        //    RightEye.transform.position = new Vector3(transform.position.x, transform.position.y, RelativePosition);
        //}

        if (RandCreated == false)
        {
            RandDist = UnityEngine.Random.Range(130.0f, 160.0f);
            RandStim = UnityEngine.Random.value;
            RandCueSide = UnityEngine.Random.value;
            RandStimVersion = UnityEngine.Random.value;
            StimDistance = RandDist;
            RandCreated = true;
        }

        if (StimDistance > 0 && RandDist != PrevRandDist && RandReceived == false && RandCreated == true) // not equal to 
        {
            RandReceived = true;
            PrevRandDist = RandDist;
        }

        if (LCamDistance > 0 && RelativePosition > (StimDistance - 1.0f) && StimDistance > 0)
        {
            PositionReached = true;
        }




        if (GameMode == GameVersion.BilateralStimDotsTraining)

        {
            //bilateral long stim only 
            if (StimIdentity == "D" && PositionReached == true) // && RandReceived == true )
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;

                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;
                //StimStartTime = Timer; 
                RandReceived = false;
                PositionReached = false;
                RandDist = 0;
                LastPosition = position;
                DStimTriggered = true;
            }

            if (StimIdentity == "V" && PositionReached == true) //&& RandReceived == true
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;

                transform.position = new Vector3(20.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(20.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;
                VertTrialCount = VertTrialCount + 1;
                //StimStartTime = Timer; 
                RandReceived = false;
                PositionReached = false;
                RandDist = 0;
                VStimTriggered = true;

            }
        }


        if (GameMode == GameVersion.BilateralStim)
        {

            //bilateral long stim only 
            if (StimIdentity == "D" && RandStimVersion >= 0.5 && PositionReached == true) // && RandReceived == true )
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;

                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;
                //StimStartTime = Timer; 
                RandReceived = false;
                PositionReached = false;
                RandDist = 0;
                LastPosition = position;
                DStimTriggered = true;
            }

            if (StimIdentity == "V" && RandStimVersion >= 0.5 && PositionReached == true) //&& RandReceived == true
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;

                transform.position = new Vector3(20.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(20.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;
                VertTrialCount = VertTrialCount + 1;
                //StimStartTime = Timer; 
                RandReceived = false;
                PositionReached = false;
                RandDist = 0;
                VStimTriggered = true;

            }


            //Alternating with Bilateral Small Stim 
            if (SmallStim == true && RandStimVersion < 0.5)
            {
                if (StimIdentity == "D" && PositionReached == true) // && RandReceived == true )
                {
                    LeftDiagGrating.transform.position = new Vector3(-50.0f, 2.5f, 9.0f);
                    RightDiagGrating.transform.position = new Vector3(50.0f, 2.5f, 9.0f);
                    LeftVertGrating.transform.position = new Vector3(-50.0f, 2.5f, 7.5f);
                    RightVertGrating.transform.position = new Vector3(50.0f, 2.5f, 7.5f);


                    LeftSmallDiag.transform.position = new Vector3(15.0f, 2.5f, transform.position.z + StimOffset);
                    RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, transform.position.z + StimOffset);

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                    StimTrialCount = StimTrialCount + 1;
                    //StimStartTime = Timer; 
                    RandReceived = false;
                    PositionReached = false;
                    RandDist = 0;
                    LastPosition = position;
                    DStimTriggered = true;
                }

                if (StimIdentity == "V" && RandStimVersion < 0.5 && PositionReached == true) //&& RandReceived == true
                {
                    LeftDiagGrating.transform.position = new Vector3(-50.0f, 2.5f, 9.0f);
                    RightDiagGrating.transform.position = new Vector3(50.0f, 2.5f, 9.0f);
                    LeftVertGrating.transform.position = new Vector3(-50.0f, 2.5f, 7.5f);
                    RightVertGrating.transform.position = new Vector3(50.0f, 2.5f, 7.5f);

                    RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, transform.position.z + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, transform.position.z + StimOffset);

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    transform.position = new Vector3(20.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(20.0f, 1.0f, RelativePosition);

                    StimTrialCount = StimTrialCount + 1;
                    VertTrialCount = VertTrialCount + 1;
                    //StimStartTime = Timer; 
                    RandReceived = false;
                    PositionReached = false;
                    RandDist = 0;
                    VStimTriggered = true;
                }
            }





            //Alternating with Long Left Unilateral 
            if (LeftUnilateral == true && RandStimVersion < 0.5)
            {
                if (StimIdentity == "D" && PositionReached == true) // && RandReceived == true )
                {
                    RightDiagGrating.transform.position = new Vector3(50.0f, 2.5f, 9.0f); //moves right diag out of the way

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                    StimTrialCount = StimTrialCount + 1;
                    //StimStartTime = Timer; 
                    RandReceived = false;
                    PositionReached = false;
                    RandDist = 0;
                    LastPosition = position;
                    DStimTriggered = true;
                }

                if (StimIdentity == "V" && RandStimVersion < 0.5 && PositionReached == true) //&& RandReceived == true
                {
                    RightVertGrating.transform.position = new Vector3(50.0f, 2.5f, 7.5f);

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    transform.position = new Vector3(20.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(20.0f, 1.0f, RelativePosition);

                    StimTrialCount = StimTrialCount + 1;
                    VertTrialCount = VertTrialCount + 1;
                    //StimStartTime = Timer; 
                    RandReceived = false;
                    PositionReached = false;
                    RandDist = 0;
                    VStimTriggered = true;
                }
            }




            //Alternating with Long Right Unilateral
            if (LeftUnilateral == true && RandStimVersion < 0.5)
            {
                if (StimIdentity == "D" && PositionReached == true) // && RandReceived == true )
                {
                    LeftDiagGrating.transform.position = new Vector3(-50.0f, 2.5f, 9.0f);

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                    StimTrialCount = StimTrialCount + 1;
                    //StimStartTime = Timer; 
                    RandReceived = false;
                    PositionReached = false;
                    RandDist = 0;
                    LastPosition = position;
                    DStimTriggered = true;
                }

                if (StimIdentity == "V" && PositionReached == true) //&& RandReceived == true
                {
                    LeftVertGrating.transform.position = new Vector3(-50.0f, 2.5f, 7.5f);

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    transform.position = new Vector3(20.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(20.0f, 1.0f, RelativePosition);

                    StimTrialCount = StimTrialCount + 1;
                    VertTrialCount = VertTrialCount + 1;
                    //StimStartTime = Timer; 
                    RandReceived = false;
                    PositionReached = false;
                    RandDist = 0;
                    VStimTriggered = true;
                }
            }





            //Alternating with Small Left Unilateral 
            if (LeftUnilateral == true && SmallStim == true && RandStimVersion < 0.5)
            {
                if (StimIdentity == "D" && PositionReached == true) // && RandReceived == true )
                {
                    LeftDiagGrating.transform.position = new Vector3(-50.0f, 2.5f, 9.0f);
                    RightDiagGrating.transform.position = new Vector3(50.0f, 2.5f, 9.0f);
                    LeftVertGrating.transform.position = new Vector3(-50.0f, 2.5f, 7.5f);
                    RightVertGrating.transform.position = new Vector3(50.0f, 2.5f, 7.5f);


                    LeftSmallDiag.transform.position = new Vector3(15.0f, 2.5f, transform.position.z + StimOffset);

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                    StimTrialCount = StimTrialCount + 1;
                    //StimStartTime = Timer; 
                    RandReceived = false;
                    PositionReached = false;
                    RandDist = 0;
                    LastPosition = position;
                    DStimTriggered = true;
                }

                if (StimIdentity == "V" && PositionReached == true && RandStimVersion < 0.5) //&& RandReceived == true
                {
                    LeftDiagGrating.transform.position = new Vector3(-50.0f, 2.5f, 9.0f);
                    RightDiagGrating.transform.position = new Vector3(50.0f, 2.5f, 9.0f);
                    LeftVertGrating.transform.position = new Vector3(-50.0f, 2.5f, 7.5f);
                    RightVertGrating.transform.position = new Vector3(50.0f, 2.5f, 7.5f);


                    LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, transform.position.z + StimOffset);

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    transform.position = new Vector3(20.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(20.0f, 1.0f, RelativePosition);

                    StimTrialCount = StimTrialCount + 1;
                    VertTrialCount = VertTrialCount + 1;
                    //StimStartTime = Timer; 
                    RandReceived = false;
                    PositionReached = false;
                    RandDist = 0;
                    VStimTriggered = true;

                }
            }


            //Alternating with Small Right Unilateral 
            if (RightUnilateral == true && SmallStim == true && RandStimVersion < 0.5)
            {
                if (StimIdentity == "D" && PositionReached == true) // && RandReceived == true )
                {
                    LeftDiagGrating.transform.position = new Vector3(-50.0f, 2.5f, 9.0f);
                    RightDiagGrating.transform.position = new Vector3(50.0f, 2.5f, 9.0f);
                    LeftVertGrating.transform.position = new Vector3(-50.0f, 2.5f, 7.5f);
                    RightVertGrating.transform.position = new Vector3(50.0f, 2.5f, 7.5f);


                    RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, transform.position.z + StimOffset);

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                    StimTrialCount = StimTrialCount + 1;
                    //StimStartTime = Timer; 
                    RandReceived = false;
                    PositionReached = false;
                    RandDist = 0;
                    LastPosition = position;
                    DStimTriggered = true;
                }

                if (StimIdentity == "V" && PositionReached == true && RandStimVersion < 0.5) //&& RandReceived == true
                {
                    LeftDiagGrating.transform.position = new Vector3(-50.0f, 2.5f, 9.0f);
                    RightDiagGrating.transform.position = new Vector3(50.0f, 2.5f, 9.0f);
                    LeftVertGrating.transform.position = new Vector3(-50.0f, 2.5f, 7.5f);
                    RightVertGrating.transform.position = new Vector3(50.0f, 2.5f, 7.5f);


                    RightSmallVert.transform.position = new Vector3(20.0f, 2.5f, transform.position.z + StimOffset);

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    transform.position = new Vector3(20.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(20.0f, 1.0f, RelativePosition);

                    StimTrialCount = StimTrialCount + 1;
                    VertTrialCount = VertTrialCount + 1;
                    //StimStartTime = Timer; 
                    RandReceived = false;
                    PositionReached = false;
                    RandDist = 0;
                    VStimTriggered = true;

                }
            }





            //
            if (Cued == false && LeftUnilateral == false && SmallStim == true)
            {

                if (RandStim < 0.5f && PositionReached == true) //(StimIdentity == "D" && CueTimer > 0.6)
                {
                    //LastPosition = position;
                    //RelativePosition = position - LastPosition;

                    //LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);

                    transform.position = new Vector3(0.0f, 1.0f, 0.0f);  // RelativePosition);
                    RightEye.transform.position = transform.position;
                    LeftEye.transform.position = transform.position;

                    LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);

                    StimTrialCount = StimTrialCount + 1;

                    DStimTriggered = true;
                    StimStarted = true;
                    RandCreated = false;
                    PositionReached = false;
                }

                if (RandStim >= 0.5f && PositionReached == true) //(StimIdentity == "D" && CueTimer > 0.6)
                {
                    //LastPosition = position;
                    //RelativePosition = position - LastPosition;

                    //LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);

                    transform.position = new Vector3(0.0f, 1.0f, 0.0f);  // RelativePosition);
                    RightEye.transform.position = transform.position;
                    LeftEye.transform.position = transform.position;

                    LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);

                    StimTrialCount = StimTrialCount + 1;

                    DStimTriggered = true;
                    StimStarted = true;
                    RandCreated = false;
                    PositionReached = false;
                }

            }

            //Alternating with Small Right Unilateral 

            if (RightUnilateral == true && SmallStim == true && Cued == false)
            {
                if (RandStim < 0.5f && PositionReached == true) //(StimIdentity == "D" && CueTimer > 0.6)
                {
                    //LastPosition = position;
                    //RelativePosition = position - LastPosition;

                    //LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);

                    transform.position = new Vector3(0.0f, 1.0f, 0.0f);  // RelativePosition);
                    RightEye.transform.position = transform.position;
                    LeftEye.transform.position = transform.position;

                    LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);

                    StimTrialCount = StimTrialCount + 1;

                    DStimTriggered = true;
                    StimStarted = true;
                    RandCreated = false;
                    PositionReached = false;
                }

                if (RandStim >= 0.5f && PositionReached == true) //(StimIdentity == "D" && CueTimer > 0.6)
                {
                    //LastPosition = position;
                    //RelativePosition = position - LastPosition;

                    //LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);

                    transform.position = new Vector3(0.0f, 1.0f, 0.0f);  // RelativePosition);
                    RightEye.transform.position = transform.position;
                    LeftEye.transform.position = transform.position;

                    LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);

                    StimTrialCount = StimTrialCount + 1;

                    DStimTriggered = true;
                    StimStarted = true;
                    RandCreated = false;
                    PositionReached = false;
                }
            }
        }





        if (GameMode == GameVersion.LeftCued || GameMode == GameVersion.RightCued)
        {
            if (PositionReached == true)
            {
                CorridorLocation = transform.position.x;

                if (RandCueSide < 0.5f && CorridorLocation == 0.0f) //left diag corridor
                {
                    DotCue.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                }

                if (RandCueSide >= 0.5f && CorridorLocation == 0.0f) //right diag corridor
                {
                    DotCue.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                }

                if (RandCueSide < 0.5f && CorridorLocation == 20.0f) //left vert corridor 
                {
                    DotCue.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);
                }

                if (RandCueSide >= 0.5f && CorridorLocation == 20.0f) //right vert corridor 
                {
                    DotCue.transform.position = new Vector3(25.0f, 2.5f, RelativePosition + StimOffset);
                }

                CueStarted = true;
                PositionReached = false;
                RandReceived = false;
                RandDist = 0;

            }

            if (CueStarted == true)
            {
                CueTimer += Time.deltaTime;
            }

            if (CueTimer > 0.1)
            {
                DotCue.transform.position = new Vector3(DotCueX, 2.5f, RelativePosition + StimOffset);
                CueShown = true;
            }

            if (GameMode == GameVersion.LeftCued)
            {
                if (RandStim < 0.5f && CueTimer > 0.3 && CueShown == true) //(StimIdentity == "D" && CueTimer > 0.6)
                {

                    //LastPosition = position;
                    //RelativePosition = position - LastPosition;

                    //LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);

                    transform.position = new Vector3(0.0f, 1.0f, 0.0f);  // RelativePosition);
                    RightEye.transform.position = transform.position;
                    LeftEye.transform.position = transform.position;

                    LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);

                    StimTrialCount = StimTrialCount + 1;

                    DStimTriggered = true;
                    StimStarted = true;
                    CueTimer = 0;
                    CueStarted = false;
                    CueShown = false;
                    RandCreated = false;
                }

                if (RandStim >= 0.5f && CueTimer > 0.3 && CueShown == true)  //(StimIdentity == "V" && CueTimer > 0.6)
                {
                    //LeftSmallVert.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);

                    //LastPosition = position;
                    //RelativePosition = position - LastPosition;

                    transform.position = new Vector3(20.0f, 1.0f, 0.0f); //RelativePosition)
                    RightEye.transform.position = transform.position;
                    LeftEye.transform.position = transform.position;

                    LeftSmallVert.transform.position = new Vector3(15.0f, 2.5f, transform.position.z + StimOffset);  //RelativePosition + StimOffset);

                    StimTrialCount = StimTrialCount + 1;
                    VertTrialCount = VertTrialCount + 1;

                    VStimTriggered = true;
                    StimStarted = true;
                    CueTimer = 0;
                    CueStarted = false;
                    CueShown = false;
                    RandCreated = false;
                }

                if (StimStarted == true)
                {
                    StimTimer += Time.deltaTime;
                }

                if (DStimTriggered == true && StimTimer > StimPresentationTime)
                {
                    LeftSmallDiag.transform.position = new Vector3(LDStimX, 2.5f, transform.position.z + StimOffset); //RelativePosition + StimOffset);
                    StimStarted = false;
                    DStimTriggered = false;
                    StimTimer = 0;
                }

                if (VStimTriggered == true && StimTimer > StimPresentationTime)
                {
                    LeftSmallVert.transform.position = new Vector3(LVStimX, 2.5f, transform.position.z + StimOffset); // RelativePosition + StimOffset);
                    StimStarted = false;
                    VStimTriggered = false;
                    StimTimer = 0;
                }

            }

            if (GameMode == GameVersion.RightCued)
            {
                if (RandStim < 0.5f && CueTimer > 0.6 && CueShown == true)
                {
                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);

                    transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                    DStimTriggered = true;
                    StimTimer += Time.deltaTime;
                    StimStarted = true;
                    CueTimer = 0;
                    CueStarted = false;
                    CueShown = false;
                    RandCreated = false;
                }

                if (RandStim >= 0.5f && CueTimer > 0.6 && CueShown == true)
                {
                    RightSmallVert.transform.position = new Vector3(25.0f, 2.5f, RelativePosition + StimOffset);

                    LastPosition = position;
                    RelativePosition = position - LastPosition;
                    transform.position = new Vector3(20.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(20.0f, 1.0f, RelativePosition);

                    VStimTriggered = true;
                    StimStarted = true;
                    CueTimer = 0;
                    CueStarted = false;
                    CueShown = false;
                    RandCreated = false;
                }

                if (StimStarted == true)
                {
                    StimTimer += Time.deltaTime;
                }

                if (RandStim < 0.5f && StimTimer > StimPresentationTime)
                {
                    RightSmallDiag.transform.position = new Vector3(RDStimX, 2.5f, RelativePosition + StimOffset);
                }

                if (RandStim >= 0.5f && StimTimer > StimPresentationTime)
                {
                    RightSmallVert.transform.position = new Vector3(RVStimX, 2.5f, RelativePosition + StimOffset);
                }

            }
        }





            if (VStimTriggered == true)
            {
                TextToSend = "2";
            }

            if (DStimTriggered == true)
            {
                TextToSend = "1";
            }


            if (StimReceived > 0)
            {
                TextToSend = "0";
                DStimTriggered = false;
                VStimTriggered = false;
            }


        
    }

        void LateUpdate()
    {
            LCamDistance = transform.position.z;
            CurrDotCueX = DotCue.transform.position.x;

            DotCue.transform.position = new Vector3(CurrDotCueX, 2.5f, LCamDistance + StimOffset);


            if (LCamDistance > 300)
            {
                TooFar = true; // need o write in the calibration for relative distance 
            }
     }

        void FixedUpdate()
    {

            //reset position at start
            if (ResetSesh == 1)
            {
                transform.position = new Vector3(0.0f, 1.0f, 0.0f);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, 0.0f);
                StimDistance = 0;
                RandReceived = false;
                LastPosition = 0;
                RelativePosition = 0;
                StimIdentity = "O";
                StimTrialCount = 0;
                VertTrialCount = 0;
                TooFar = false;

            }
        }

    // receive thread 
    private void ReceiveData()
    {
        print("allocating client");
        IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, ReceivePort);
        client = new UdpClient(ReceivePort);
        client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (receiveRunning)
        {
            try
            {
                data = client.Receive(ref anyIP); //byte[] data
                text = Encoding.UTF8.GetString(data);
                // latest UDPpacket
                lastReceivedUDPPacket = text;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    private void SendData()
    {
        print("sending client");
        IPEndPoint SendtoIP = new IPEndPoint(IPAddress.Parse(SendIP), SendPort);
        SendClient = new UdpClient(SendPort);
        SendClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (sendRunning)
        {
            try
            {
                DataToSend = Encoding.UTF8.GetBytes(TextToSend);
                SendClient.Send(DataToSend, DataToSend.Length, SendtoIP);
                lastSentUDPPacket = TextToSend;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    public string getLatestUDPPacket()
    {
        return lastReceivedUDPPacket;
        return lastSentUDPPacket;
    }

    void OnApplicationQuit()
    {
        // stop listening thread
        receiveRunning = false;
        sendRunning = false;
        client.Close();
        SendClient.Close();

        // wait for listening thread to terminate (max. 500ms)		
        receiveThread.Join(500);
        sendThread.Join(500);
    }

}
