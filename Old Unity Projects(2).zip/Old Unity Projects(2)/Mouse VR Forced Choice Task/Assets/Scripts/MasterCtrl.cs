﻿using UnityEngine;
using System.Collections;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class MasterCtrl : MonoBehaviour
{
    public enum GameVersion {BilateralCorridorTraining,
                             AlternateCorridorPanel,
                             ForcedChoiceTask,
                            CuedLowContrastForcedChoice};

    public GameVersion GameMode;
    public bool SmallStim;
    public bool BilateralStim;
    public bool Cued;
    public bool AlternateNoCue;

    public string StimIdentity;
    public string StimLength;
    public string StimSide; 

    public float StimPresentationTime;
    public float CuePresentTime; 
    public float CueStimGap; 
    public float StimOffset;

    public string lastReceivedUDPPacket = "";
    public string lastSentUDPPacket = "";

    public int StimTrialCount;
    private int VertTrialCount;
    public float RelativePosition;
    public float StimDistance;
    private float StimDist; 

    private Vector3 GroundCoord;
    private Vector3 CeilingCoord;
    private Vector3 VertGreyRWCoord;
    private Vector3 VertGreyLWCoord;
    private Vector3 NewPosition;
    private Vector3 LeftVertDefault;
    private Vector3 RightVertDefault;
    private Vector3 LeftVertGratingDisplaced;
    private Vector3 RightVertGratingDisplaced;
    private Vector3 LeftDiagGratingDisplaced;
    private Vector3 RightDiagGratingDisplaced;
    private Vector3 Location;

    UdpClient client;
    UdpClient SendClient;
    private Thread receiveThread;
    private Thread sendThread;

    private bool receiveRunning;
    private bool sendRunning;
    private bool Reset;
    private bool RandReceived;
    private bool PositionReached;
    private bool VertCloneAppeared;
    private bool VStimTriggered;
    private bool DStimTriggered;
    private bool VStim;
    private bool DStim;
    private bool CorridorStarted;

    private bool SmallStimStarted;
    private bool RandCreated;
    private bool CueShown;
    private bool TimerStarted;
    private bool StimMoved;
    private bool Small;
    private bool Panel;
    private bool CueStarted;
    private bool ContrastSet;
    private bool MoveVStim;
    private bool MoveDStim; 

    private bool FakeCueStarted;
    public bool NoCue;
    private bool CueOrNotCreated;
    private bool UpcomingStim;
    private bool StimShown;
    private bool RandPunishCreated;
    public bool Punish;


    private int ResetSesh;
    private int StimReceived;
    private int stringSize;
    private int resetPos;
    private int RandDist;

    private int FwdInstanNum;
    private int RevInstanNum;
    private int InstanLength;
    private int origin;
    private int revNum; 

    private int SendPort;
    private int ReceivePort;
    private byte[] data;
    private byte[] DataToSend;

    private int ContrastVersion;
    private int[] FakeCueDist;
    private int Flashes;
    private int DistFrac;
    private int FlashSide;
    private int DotDist;
    private int ItA;

    private string ContrastLevel;
    private string text;
    private string TextToSend;
    private string PosIn;
    private string RandNum;
    private string StimTrig;
    private string NewTrial;
    private string itString;
    private string RWCloneName;
    private string LWCloneName;
    private string ReceivedStim;
    private string ResetSession;
    private string StimVariant;
    private string StimType;

    private string CloneNum;
    private string udpIn;
    private string udpOut;
    private string LCloneName;
    private string RCloneName;
    private string FWallCloneNum;
    private string BWallCloneNum;
    private string StimWindow;
    private string Task;
    private string SendIP;   
    private string LVMessage; 

    private float DiagRandZ;
    public float StimTimer; 
    private float CueTimer;
    private float NextDot;
    private float fps;
    private float RandStim;
    private int RandStimVersion;
    private int StimVersion; 

    private float NumFlashes;
    private float RandSide;
    private float OldPosition;
    private float FakeCueTimer;
    private float FakeCueX;
    private float LastDist;
    private float CueOrNot;
    private float RandCueSide;
    private float PositionAtMove;
    private float LastPosition;
    private float RandPunish;

    private float RCamDistance; //cam location
    private float LCamDistance;
    private float position; //UDP position
    private float smoothing;
    private float fracMovt;
    private float CorridorLocation;
    private float CamX;

    private float PrevRandDist;
    private float offset;
    private float CueOffset;
    private float RandDot;
    private float RightCueX;
    private float LeftCueX;
    private float CurrLeftCueX;
    private float CurrRightCueX;

    private float VertRandY;
    private float VRandY;
    private float VertRandDot;
    private float deltaTime; 

    private GameObject VRBDotClone;
    private GameObject VLBDotClone;
    private GameObject VRWDotClone;
    private GameObject VLWDotClone;
    private GameObject VShuffleRDot;
    private GameObject VShuffleLDot;
    private GameObject WhiteDotClone;
    private GameObject BlackDotClone;

    private GameObject VCeilingClone;
    private GameObject RevVCeilingClone;
    private GameObject VGrndClone;
    private GameObject RevVGrndClone;
    private GameObject VRWClone;
    private GameObject VLWClone;

    public GameObject LeftVertGrating;
    public GameObject RightVertGrating;
    public GameObject LeftDiagGrating;
    public GameObject RightDiagGrating;
    public GameObject LeftCue;
    public GameObject RightCue;
    public GameObject FakeCue;

    public GameObject VertFullContrastR;
    public GameObject VertContrast1R;
    public GameObject VertContrast2R;
    public GameObject VertContrast3R;
    public GameObject VertContrast4R;
    public GameObject VertContrast5R;
    public GameObject VertContrast6R;
    public GameObject VertContrast7R;
    public GameObject VertContrast8R;
    public GameObject VertNoContrastR;
    public GameObject VertFullContrastL;
    public GameObject VertContrast1L;
    public GameObject VertContrast2L;
    public GameObject VertContrast3L;
    public GameObject VertContrast4L;
    public GameObject VertContrast5L;
    public GameObject VertContrast6L;
    public GameObject VertContrast7L;
    public GameObject VertContrast8L;
    public GameObject VertNoContrastL;

    public GameObject DiagFullContrastR;
    public GameObject DiagContrast1R;
    public GameObject DiagContrast2R;
    public GameObject DiagContrast3R;
    public GameObject DiagContrast4R;
    public GameObject DiagContrast5R;
    public GameObject DiagContrast6R;
    public GameObject DiagContrast7R;
    public GameObject DiagContrast8R;
    public GameObject DiagNoContrastR;
    public GameObject DiagFullContrastL;
    public GameObject DiagContrast1L;
    public GameObject DiagContrast2L;
    public GameObject DiagContrast3L;
    public GameObject DiagContrast4L;
    public GameObject DiagContrast5L;
    public GameObject DiagContrast6L;
    public GameObject DiagContrast7L;
    public GameObject DiagContrast8L;
    public GameObject DiagNoContrastL;

    private GameObject LeftSmallVert;
    private GameObject RightSmallVert;
    private GameObject LeftSmallDiag;
    private GameObject RightSmallDiag; 

    public GameObject LeftEye;
    public GameObject RightEye;
    public GameObject VertCeiling;
    public GameObject VertGreyRW;
    public GameObject VertGreyLW;
    public GameObject VertGround;
    public GameObject WhiteDot;
    public GameObject BlackDot; 

    public Material Black;
    public Material LightGrey;
    public Material White;

    private string WrongLick;
    private int DistPunish;
    


    void Awake()
    {

        LeftVertGratingDisplaced = new Vector3(-40.0f, 2.5f, 15f);
        RightVertGratingDisplaced = new Vector3(40.0f, 2.5f, 15f);

        LeftDiagGratingDisplaced = new Vector3(-60.0f, 2.5f, 15f);
        RightDiagGratingDisplaced = new Vector3(60.0f, 2.5f, 15f);


        for (int i = 1; i < 21; i++)
        { 
            GameObject VCeilingClone = Instantiate(VertCeiling) as GameObject;
            VCeilingClone.transform.position = new Vector3(0.0f, 5.0f, i * 50.0f + 25f);          

            GameObject VLWClone = Instantiate(VertGreyLW) as GameObject;
            GameObject VRWClone = Instantiate(VertGreyRW) as GameObject;

            VLWClone.transform.position = new Vector3(-5.01f, 2.5f, i * 50.0f);
            VRWClone.transform.position = new Vector3(5.01f, 2.5f, i * 50.0f);

            GameObject VGrndClone = Instantiate(VertGround) as GameObject;
            VGrndClone.transform.position = new Vector3(0.0f, -2.0f, i * 100.0f + 10f);
        }

        for (int i = 1; i < 4; i++)
        {
            GameObject RevVCeilingClone = Instantiate(VertCeiling) as GameObject;
            RevVCeilingClone.transform.position = new Vector3(0.0f, 5.0f, i * -50.0f + 25f);

            GameObject RevVGrndClone = Instantiate(VertGround) as GameObject;
            RevVGrndClone.transform.position = new Vector3(0.0f, -2.0f, i * -100.0f + 10f);

            GameObject RevVLWClone = Instantiate(VertGreyLW) as GameObject;
            GameObject RevVRWClone = Instantiate(VertGreyRW) as GameObject;

            RevVLWClone.transform.position = new Vector3(-5.01f, 2.5f, i * -50.0f);
            RevVRWClone.transform.position = new Vector3(5.01f, 2.5f, i * -50.0f);

        }

        if (GameMode == GameVersion.BilateralCorridorTraining)

        {         

            for (int i = 1; i < 250; i++)
            {
                VertRandY = UnityEngine.Random.Range(0.0f, 4.0f);
                VertRandDot = UnityEngine.Random.value;

                if (VertRandDot < 0.5f)
                {
                    GameObject VRWDotClone = Instantiate(WhiteDot) as GameObject;
                    GameObject VLWDotClone = Instantiate(WhiteDot) as GameObject;

                    VRWDotClone.transform.position = new Vector3(-4.98f, VertRandY, i * 2 + 40);
                    VLWDotClone.transform.position = new Vector3(4.98f, VertRandY, i * 2 + 40);
                }

                if (VertRandDot > 0.5f)
                {
                    GameObject VRBDotClone = Instantiate(BlackDot) as GameObject;
                    GameObject VLBDotClone = Instantiate(BlackDot) as GameObject;

                    VRBDotClone.transform.position = new Vector3(-4.98f, VertRandY, i * 2 + 40);
                    VLBDotClone.transform.position = new Vector3(4.98f, VertRandY, i * 2 + 40);
                }
            }
        }

        if(GameMode == GameVersion.ForcedChoiceTask || GameMode == GameVersion.CuedLowContrastForcedChoice)
        {
            LeftVertGrating.transform.position = LeftVertGratingDisplaced;
            RightVertGrating.transform.position = RightVertGratingDisplaced;
            LeftDiagGrating.transform.position = LeftVertGratingDisplaced;
            RightDiagGrating.transform.position = RightVertGratingDisplaced;
        }
        

        offset = 15.0f;
        RandReceived = false;
        PrevRandDist = 0;
        TextToSend = "0";
        StimTrialCount = 0;
        RelativePosition = 0;
        StimTimer = 0;
        CueShown = false;
        CueTimer = 0;
        UpcomingStim = false; 
    }       

    void Start()
    {
        Debug.Log("displays connected:" + Display.displays.Length);

        init();
        Application.runInBackground = true;

        OldPosition = 0;

        if(GameMode == GameVersion.CuedLowContrastForcedChoice)
        {
            Cued = true;
            AlternateNoCue = true;
            CueOrNot = 0;
            CueStarted = false; 
        }

        CueOffset = StimOffset;
        LeftCueX = LeftCue.transform.position.x;
        RightCueX = RightCue.transform.position.x;
        NoCue = false;

        StimIdentity = "N";
        RandCreated = false; 
    }

    public void Activate()
    {
        Screen.fullScreen = true;
    }

    private void init()
    {
        print("UDP.init()");

        ReceivePort = 8888;
        SendPort = 8051;
        SendIP = "169.230.68.184";

        receiveRunning = true;
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();

        sendRunning = true;
        sendThread = new Thread(new ThreadStart(SendData));
        sendThread.IsBackground = true;
        sendThread.Start();
    }


    void Update()
    {
        deltaTime += (Time.deltaTime - deltaTime) * 0.1f;
        fps = 1.0f / deltaTime;

        TextToSend = "0";

        udpIn = lastReceivedUDPPacket;
        stringSize = udpIn.Length;

        if (stringSize > 0)
        {
            ReceivedStim = udpIn.Substring(0, 1);
            ResetSession = udpIn.Substring(1, 1);
            StimIdentity = udpIn.Substring(2, 1);
            StimVariant = udpIn.Substring(3, 1);
            ContrastLevel = udpIn.Substring(4, 1);
            RandNum = udpIn.Substring(5, 3);
            WrongLick = udpIn.Substring(8, 1);
            PosIn = udpIn.Substring(9, (stringSize - 9));
        }

        int.TryParse(ReceivedStim, out StimReceived);
        int.TryParse(ResetSession, out ResetSesh);
        int.TryParse(StimVariant, out RandStimVersion);
        int.TryParse(ContrastLevel, out ContrastVersion);
        int.TryParse(RandNum, out RandDist);
        int.TryParse(WrongLick, out DistPunish); 
        float.TryParse(PosIn, out position);      

        RelativePosition = position - LastPosition;
        RCamDistance = RightEye.transform.position.z;
        LCamDistance = LeftEye.transform.position.z;
        StimDistance = ((float)RandDist);


        //Cam Movement 
        if (position != LCamDistance)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, RelativePosition);
            RightEye.transform.position = new Vector3(transform.position.x, transform.position.y, RelativePosition);
        }

        if (GameMode == GameVersion.AlternateCorridorPanel)
        {
            RightSmallVert = VertFullContrastR;
            LeftSmallVert = VertFullContrastL;
            RightSmallDiag = DiagFullContrastR;
            LeftSmallDiag = DiagFullContrastL;
        }

        if (GameMode == GameVersion.ForcedChoiceTask || GameMode == GameVersion.CuedLowContrastForcedChoice)          
        {
                if (ContrastVersion == 0)
                {
                    RightSmallVert = VertFullContrastR;
                    LeftSmallVert = VertFullContrastL;
                    RightSmallDiag = DiagFullContrastR;
                    LeftSmallDiag = DiagFullContrastL;
            }

                if (ContrastVersion == 1)
                {
                    RightSmallVert = VertContrast1R;
                    LeftSmallVert = VertContrast1L;
                    RightSmallDiag = DiagContrast1R;
                    LeftSmallDiag = DiagContrast1L;
            }

                if (ContrastVersion == 2)
                {
                    RightSmallVert = VertContrast2R;
                    LeftSmallVert = VertContrast2L;
                    RightSmallDiag = DiagContrast2R;
                    LeftSmallDiag = DiagContrast2L;
                }

                if (ContrastVersion == 3)
                {
                    RightSmallVert = VertContrast3R;
                    LeftSmallVert = VertContrast3L;
                    RightSmallDiag = DiagContrast3R;
                    LeftSmallDiag = DiagContrast3L;

                 }
    
                if (ContrastVersion == 4)
                {
                    RightSmallVert = VertContrast4R;
                    LeftSmallVert = VertContrast4L;
                    RightSmallDiag = DiagContrast4R;
                    LeftSmallDiag = DiagContrast4L;
                 }

                if (ContrastVersion == 5)
                {
                    RightSmallVert = VertContrast5R;
                    LeftSmallVert = VertContrast5L;
                    RightSmallDiag = DiagContrast5R;
                    LeftSmallDiag = DiagContrast5L;
                }

                if (ContrastVersion == 6)
                {
                    RightSmallVert = VertContrast6R;
                    LeftSmallVert = VertContrast6L;
                    RightSmallDiag = DiagContrast6R;
                    LeftSmallDiag   = DiagContrast6L;
            }

                if (ContrastVersion == 7)
                {
                    RightSmallVert = VertContrast7R;
                    LeftSmallVert = VertContrast7L;
                    RightSmallDiag = DiagContrast7R;
                    LeftSmallDiag = DiagContrast7L;
            }

                if (ContrastVersion == 8)
                {
                    RightSmallVert = VertContrast8R;
                    LeftSmallVert = VertContrast8L;
                    RightSmallDiag = DiagContrast8R;
                    LeftSmallDiag = DiagContrast8L;
            }

                if (ContrastVersion == 9)
                {
                    RightSmallVert = VertNoContrastR;
                    LeftSmallVert = VertNoContrastL;
                    RightSmallDiag = DiagNoContrastR;
                    LeftSmallDiag = DiagNoContrastL;
            }
        }

  

        if (StimDistance != OldPosition && GameMode == GameVersion.CuedLowContrastForcedChoice)
        {

            if (CueStarted == false || SmallStimStarted == false || UpcomingStim == false)
            {
                if (StimDistance < 100)
                {
                    NumFlashes = UnityEngine.Random.Range(2.0f, 4.0f);
                }
                if (StimDistance > 100 && StimDistance < 200)
                {
                NumFlashes = UnityEngine.Random.Range(5.0f, 8.0f);
                }
                if (StimDistance > 200 && StimDistance < 300)
                {
                    NumFlashes = UnityEngine.Random.Range(9.0f, 12.0f);
                }


             Flashes = Convert.ToInt32(NumFlashes);
            DistFrac = Convert.ToInt32(StimDistance / Flashes);
            FakeCueDist = new int[Flashes];
            OldPosition = StimDistance;
            LastDist = Convert.ToInt32(StimDistance);


            for (int i = 1; i < Flashes + 1; i++)
            {
                NextDot = DistFrac * i;
                DotDist = Convert.ToInt32(UnityEngine.Random.Range(DistFrac * (i - 1), NextDot));

                if (DotDist < 10)
                {
                    DotDist = DotDist + 20;
                }

                if (StimDistance - DotDist < 40)
                {
                    DotDist = DotDist - 40;
                }

                if (i > 1)
                {
                    if (DotDist - LastDist < 10)
                    {
                        DotDist = DotDist + 10;
                    }
                }

                if(DotDist - LastDist < 40)
                {
                    DotDist = DotDist + 10; 
                }

                FakeCueDist[i - 1] = DotDist;

                LastDist = DotDist;
            }

            Array.Sort(FakeCueDist);

            ItA = 1;
            }
        }

            if(GameMode == GameVersion.CuedLowContrastForcedChoice)
        {
            if(RelativePosition > StimDistance - 20.0f)
            {
                UpcomingStim = true; 
            }
            if (RelativePosition < 5.0f)
            {
                UpcomingStim = false;
            }

            if (RelativePosition > FakeCueDist[ItA] && ItA < (Flashes - 1) && Cued == true)
            {
               if ((NoCue == true && UpcomingStim == false) || (NoCue == false && CueStarted == false))
                {
                    RandSide = UnityEngine.Random.value;
                    if (RandSide < 0.5)
                    {
                        FakeCueX = -4.98f;
                        FlashSide = 2;
                    }

                    if (RandSide >= 0.5)
                    {
                        FakeCueX = 4.98f;
                        FlashSide = 1;
                    }

                    FakeCue.transform.position = new Vector3(FakeCueX, 2.5f, FakeCueDist[ItA] + CueOffset);
                    FakeCueStarted = true;
                    ItA = ItA + 1;
                }

            }


            if (FakeCueStarted == true)
            {
                FakeCueTimer += Time.deltaTime;
            }

            if (FakeCueTimer > CuePresentTime)
            {
                FakeCue.transform.position = new Vector3(-10.0f, 0.5f, 0.0f);
            }

            if (FakeCueTimer > CuePresentTime + 0.5f)
            {
                FakeCueTimer = 0;
                FakeCueStarted = false;
                FlashSide = 0;
            }
        }

        if (RandCreated == false)
        {
            RandCueSide = UnityEngine.Random.value;
            RandCreated = true;        
        }

        if (RandDist == PrevRandDist)
        {
            RandDist = RandDist + 1; 
        }

        if (StimDistance > 0 && RandDist != PrevRandDist && RandReceived == false)
        {
            RandReceived = true;
            PrevRandDist = RandDist;            
        }


        if (GameMode == GameVersion.AlternateCorridorPanel)
        {
            if (RandStimVersion == 0)
            {
                StimLength = "Corridor";
            }
            if (RandStimVersion == 1)
            {
                StimLength = "Panel";
            }
        }


        if (GameMode == GameVersion.CuedLowContrastForcedChoice || GameMode == GameVersion.ForcedChoiceTask)
        {
            if (RandStimVersion == 0)
            {
                StimSide = "Left";
            }
            if (RandStimVersion == 1)
            {
                StimSide = "Right";
            }
        }
        else
        {
            StimSide = "Both"; 
        }

        if(DistPunish == 1)
        {
            Punish = true; 
        }

        if (Punish == true && StimDistance > 0)
        {
            StimDistance = StimDistance * 2; 
        }

        if (LCamDistance > 0 && RelativePosition > (StimDistance - 1.0f) && StimDistance > 0 && PositionReached == false)
        {
            PositionReached = true;
            Punish = false; 
        }


        if (AlternateNoCue == true && CueOrNotCreated == false)
        {
            CueOrNot = UnityEngine.Random.value; 
            CueOrNotCreated = true;
        }

        if (CueOrNot < 0.4)
        {
            NoCue = true;
        }
        else
        {
            NoCue = false;
        }


 
        if (Cued == true && PositionReached == true && CueStarted == false)
        {
            if(NoCue == false)
            {
                if (RandCueSide < 0.5f && RandCueSide != 0)
                {
                    LeftCue.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + CueOffset);
                }

                if (RandCueSide >= 0.5f)
                {
                    RightCue.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + CueOffset);
                }
                CueStarted = true;
            }
            else
            {
                CueStarted = false;
            }
        }

        if (CueStarted == true)
        {
            CueTimer += Time.deltaTime;
        }

        if (CueTimer > CuePresentTime)
        {
            RightCue.transform.position = new Vector3(RightCueX, 2.5f, RelativePosition + CueOffset);
            LeftCue.transform.position = new Vector3(LeftCueX, 2.5f, RelativePosition + CueOffset);
            FakeCue.transform.position = new Vector3(-10.0f, 0.5f, 0.0f);
        }

        if (CueTimer > CuePresentTime + CueStimGap)
        {
            CueShown = true;
        }


        if (GameMode == GameVersion.BilateralCorridorTraining)
        {
            if (StimIdentity == "D" && PositionReached == true && RandReceived == true )
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;

                LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                RightVertGrating.transform.position = RightVertGratingDisplaced;
                LeftDiagGrating.transform.position = new Vector3(-5.0f, 2.5f, 15f);
                RightDiagGrating.transform.position = new Vector3(5.0f, 2.5f, 15f);

                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;
                //StimStartTime = Timer; 
                RandReceived = false;
                PositionReached = false;
                RandDist = 0;
                Reset = false;
                LastPosition = position;
                DStimTriggered = true;
            }


            if (StimIdentity == "V" && PositionReached == true && RandReceived == true)
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;

                LeftVertGrating.transform.position = new Vector3(-5.0f, 2.5f, 15f);
                RightVertGrating.transform.position = new Vector3(5.0f, 2.5f, 15f);
                LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                RightDiagGrating.transform.position = RightDiagGratingDisplaced;

                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;
                VertTrialCount = VertTrialCount + 1;
                RandReceived = false;
                PositionReached = false;
                RandDist = 0;
                Reset = false;
                VStimTriggered = true;

            }
        }



        if (GameMode == GameVersion.AlternateCorridorPanel)
        {
            if (StimIdentity == "V")
            {
                if (RandStimVersion == 1 && PositionReached == true && CorridorStarted == false && SmallStimStarted == false && RandReceived == true) //vert panel
                {
                    VStim = true; 
                    SmallStim = true;
                    BilateralStim = true; 

                    LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                    RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);

                    LeftSmallDiag.transform.position = new Vector3(-30.0f, 2.5f, RelativePosition + StimOffset);
                    RightSmallDiag.transform.position = new Vector3(30.0f, 2.5f, RelativePosition + StimOffset);

                    LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                    RightVertGrating.transform.position = RightVertGratingDisplaced;
                    LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                    RightDiagGrating.transform.position = RightDiagGratingDisplaced;                   

                    SmallStimStarted = true; 
                    StimMoved = true;
                    VStimTriggered = true;

                }

                if (RandStimVersion == 0 && PositionReached == true && CorridorStarted == false && SmallStimStarted == false && RandReceived == true)
                {
                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    RightSmallVert.transform.position = new Vector3(10.0f, 2.5f, RelativePosition + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(-10.0f, 2.5f, RelativePosition + StimOffset);

                    LeftSmallDiag.transform.position = new Vector3(-30.0f, 2.5f, RelativePosition + StimOffset);
                    RightSmallDiag.transform.position = new Vector3(30.0f, 2.5f, RelativePosition + StimOffset);

                    LeftVertGrating.transform.position = new Vector3(-5.0f, 2.5f, 15f);
                    RightVertGrating.transform.position = new Vector3(5.0f, 2.5f, 15f);

                    LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                    RightDiagGrating.transform.position = RightDiagGratingDisplaced;

                    transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                    CorridorStarted = true;
                    SmallStimStarted = false;
                    PositionReached = false;
                    VStimTriggered = true;
                    RandReceived = false;
                }
            }

            if (StimIdentity == "D")
            {
                if (RandStimVersion == 1 && PositionReached == true && CorridorStarted == false && SmallStimStarted == false && RandReceived == true) //diag panel
                {
                    DStim = true;
                    SmallStim = true;
                    BilateralStim = true;               

                    LeftSmallVert.transform.position = new Vector3(-10.0f, 2.5f, RelativePosition + StimOffset);
                    RightSmallVert.transform.position = new Vector3(10.0f, 2.5f, RelativePosition + StimOffset);

                    LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                    RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);

                    LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                    RightVertGrating.transform.position = RightVertGratingDisplaced;
                    LeftDiagGrating.transform.position = LeftDiagGratingDisplaced;
                    RightDiagGrating.transform.position = RightDiagGratingDisplaced;

                    SmallStimStarted = true;
                    StimMoved = true;
                    DStimTriggered = true;
                }

                if (RandStimVersion == 0 && PositionReached == true && CorridorStarted == false && SmallStimStarted == false && RandReceived == true)
                {

                    LastPosition = position;
                    RelativePosition = position - LastPosition;

                    LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                    RightVertGrating.transform.position = RightVertGratingDisplaced;

                    RightSmallVert.transform.position = new Vector3(10.0f, 2.5f, RelativePosition + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(-10.0f, 2.5f, RelativePosition + StimOffset);

                    LeftSmallDiag.transform.position = new Vector3(-30.0f, 2.5f, RelativePosition + StimOffset);
                    RightSmallDiag.transform.position = new Vector3(30.0f, 2.5f, RelativePosition + StimOffset);

                    LeftVertGrating.transform.position = LeftVertGratingDisplaced;
                    RightVertGrating.transform.position = RightVertGratingDisplaced;

                    LeftDiagGrating.transform.position = new Vector3(-5.0f, 2.5f, 15f); 
                    RightDiagGrating.transform.position = new Vector3(5.0f, 2.5f, 15f);

                    transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                    RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                    CorridorStarted = true;
                    PositionReached = false;
                    DStimTriggered = true;
                    RandReceived = false;
                }
            }

                if (CorridorStarted == true) // for corridors
                {
                    StimTrialCount = StimTrialCount + 1;
                    CorridorStarted = false; 
                }

                if (SmallStimStarted == true) // for panels
                {
                    StimTimer += Time.deltaTime;
                    
                    if(VStim == true)
                    {
                        MoveVStim = true;
                    }

                    if (DStim == true)
                    {
                        MoveDStim = true;
                    }
                }


                if (StimTimer > StimPresentationTime && StimMoved == true) 
                {
                   
                    if(VStim == true)
                    {
                        LeftSmallVert.transform.position = new Vector3(-15.0f, 2.5f, StimOffset);
                        RightSmallVert.transform.position = new Vector3(15.0f, 2.5f, StimOffset);
                    }

                    if (DStim == true)
                    {
                        LeftSmallDiag.transform.position = new Vector3(-30.0f, 2.5f, StimOffset);
                        RightSmallDiag.transform.position = new Vector3(30.0f, 2.5f, StimOffset);
                    }

                    StimMoved = false;
                    DStim = false;
                    VStim = false;
                    MoveVStim = false;
                    MoveDStim = false;

            }

            if (StimTimer > StimPresentationTime + 2.0f)
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;
                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;

                SmallStimStarted = false;
                StimTimer = 0;
                StimMoved = false;
                RandCreated = false;
                PositionReached = false;
                RandReceived = false;
                SmallStim = false; 

            }

        }



        if (GameMode == GameVersion.ForcedChoiceTask)
        {
            BilateralStim = false; 
            Cued = false; 
            NoCue = true; 

            if (StimIdentity == "V" && PositionReached == true)
            {
                if(RandStimVersion == 0)
                {
                    RightSmallVert.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                }           

                if(RandStimVersion == 1)
                {
                    RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(-15.0f, 2.5f, RelativePosition + StimOffset);
                }
              
                VStimTriggered = true;
                SmallStimStarted = true;
                MoveVStim = true;
            }

            if (StimIdentity == "D" && PositionReached == true)
            {
                if (RandStimVersion == 0)
                {
                    RightSmallDiag.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);
                    LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                }

                if (RandStimVersion == 1)
                {
                    RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                    LeftSmallDiag.transform.position = new Vector3(-15.0f, 2.5f, RelativePosition + StimOffset);
                }

                DStimTriggered = true;
                SmallStimStarted = true;
                MoveDStim = true;
            }

            if (SmallStimStarted == true)
            {
                StimTimer += Time.deltaTime;
            }


            if (StimTimer > StimPresentationTime) // StimStarted == true && Static == false
            {
                if (MoveVStim == true)
                {
                    LeftSmallVert.transform.position = new Vector3(-15.0f, 2.5f, StimOffset);
                    RightSmallVert.transform.position = new Vector3(15.0f, 2.5f, StimOffset);
                }

                if (MoveDStim == true)
                {
                    LeftSmallDiag.transform.position = new Vector3(-30.0f, 2.5f, StimOffset);
                    RightSmallDiag.transform.position = new Vector3(30.0f, 2.5f, StimOffset);
                }

                StimMoved = true;
                MoveVStim = false;
                MoveDStim = false;
            }

            if (StimMoved == true && StimTimer > StimPresentationTime + 2.0f)
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;
                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;

                SmallStimStarted = false;
                StimTimer = 0;
                StimMoved = false;
                RandCreated = false;
                RandReceived = false;
                PositionReached = false;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
            }

        }

        if (GameMode == GameVersion.CuedLowContrastForcedChoice)
        {

            if ((NoCue == false && PositionReached == true && CueTimer > CuePresentTime && CueShown == true) || (NoCue == true && PositionReached == true))
            {

                if (StimIdentity == "V" && PositionReached == true)
                {
                    if (RandStimVersion == 0)
                    {
                        RightSmallVert.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);
                        LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                    }

                    if (RandStimVersion == 1)
                    {
                        RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                        LeftSmallVert.transform.position = new Vector3(-15.0f, 2.5f, RelativePosition + StimOffset);
                    }

                    VStimTriggered = true;
                    SmallStimStarted = true;
                    MoveVStim = true;
                }

                if (StimIdentity == "D" && PositionReached == true)
                {
                    if (RandStimVersion == 0)
                    {
                        RightSmallDiag.transform.position = new Vector3(15.0f, 2.5f, RelativePosition + StimOffset);
                        LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, RelativePosition + StimOffset);
                    }

                    if (RandStimVersion == 1)
                    {
                        RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, RelativePosition + StimOffset);
                        LeftSmallDiag.transform.position = new Vector3(-15.0f, 2.5f, RelativePosition + StimOffset);
                    }

                    DStimTriggered = true;
                    SmallStimStarted = true;
                    MoveDStim = true;
                }
            }


            if (SmallStimStarted == true)
            {
                StimTimer += Time.deltaTime;
            }


            if (StimTimer > StimPresentationTime)
            {
                if (MoveVStim == true)
                {
                    LeftSmallVert.transform.position = new Vector3(-15.0f, 2.5f, StimOffset);
                    RightSmallVert.transform.position = new Vector3(15.0f, 2.5f, StimOffset);
                }

                if (MoveDStim == true)
                {
                    LeftSmallDiag.transform.position = new Vector3(-30.0f, 2.5f, StimOffset);
                    RightSmallDiag.transform.position = new Vector3(30.0f, 2.5f, StimOffset);
                }

                StimMoved = true;
                MoveVStim = false;
                MoveDStim = false;
            }

            if (StimMoved == true && StimTimer > StimPresentationTime + 2.0f)
            {
                LastPosition = position;
                RelativePosition = position - LastPosition;
                transform.position = new Vector3(0.0f, 1.0f, RelativePosition);
                RightEye.transform.position = new Vector3(0.0f, 1.0f, RelativePosition);

                StimTrialCount = StimTrialCount + 1;

                SmallStimStarted = false;
                StimTimer = 0;
                StimMoved = false;
                RandCreated = false;
                RandReceived = false;
                PositionReached = false;
                CueTimer = 0;
                CueStarted = false;
                CueShown = false;
            }

        }


        if(VStimTriggered == true)
        {
            TextToSend = "1"; 
        }

        if (DStimTriggered == true)
        {
            TextToSend = "2";
        }

            if (SmallStim == true)
            {
                TextToSend = TextToSend + "S";
            }
            else
            {
                TextToSend = TextToSend + "N";
            }

        if (StimSide == "Right")
        {
            TextToSend = TextToSend + "R";
        }       

        if (StimSide == "Left")
        {
            TextToSend = TextToSend + "L";
        }
        if (StimSide == "Both")
        {
            TextToSend = TextToSend + "B";
        }

        if (Cued == true)
            {
                if (NoCue == false)
                {
                    if (RandCueSide < 0.5f && RandCueSide != 0)
                    {
                        TextToSend = TextToSend + "L";
                    }
                    else if (RandCueSide >= 0.5f)
                    {
                        TextToSend = TextToSend + "R";
                    }
                }
                if (NoCue == true)
                {
                    TextToSend = TextToSend = TextToSend + "N";
                }
            }
            else
            {
                TextToSend = TextToSend = TextToSend + "X";
            }



        if (FlashSide == 1)
        {
            TextToSend = TextToSend + "1";
        }
        if (FlashSide == 2)
        {
            TextToSend = TextToSend + "2";
        }
        if (FlashSide == 0)
        {
            TextToSend = TextToSend + "0";
        }



        if (StimReceived > 0)
        {
            if(VStimTriggered == true && MoveVStim == false)
            {
                VStimTriggered = false;
            }

            if (DStimTriggered == true && MoveDStim == false)
            {
                DStimTriggered = false;
            }

        }
    }




    void LateUpdate()
    {

        LCamDistance = transform.position.z;

        if (FakeCueStarted == true)
        {
            if (FakeCueTimer > 0 && FakeCueTimer < CuePresentTime && RandSide < 0.5f && RandSide != 0)
            {
                FakeCue.transform.position = new Vector3(-4.98f, 2.5f, LCamDistance + StimOffset);
            }

            if (FakeCueTimer > 0 && FakeCueTimer < CuePresentTime && RandSide >= 0.5f)
            {
                FakeCue.transform.position = new Vector3(4.98f, 2.5f, LCamDistance + StimOffset);
            }
        }


        if (CueTimer > 0 && CueTimer < CuePresentTime && RandCueSide < 0.5f && RandCueSide != 0)
        {
            LeftCue.transform.position = new Vector3(-4.98f, 2.5f, LCamDistance + StimOffset);
        }

        if (CueTimer > 0 && CueTimer < CuePresentTime && RandCueSide >= 0.5f)
        {
            RightCue.transform.position = new Vector3(4.98f, 2.5f, LCamDistance + StimOffset);
        }

        if (MoveVStim == true)
        {
            if (GameMode == GameVersion.AlternateCorridorPanel)
            {
                LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
            }

            if (GameMode == GameVersion.ForcedChoiceTask || GameMode == GameVersion.CuedLowContrastForcedChoice)
            {
                if (RandStimVersion == 0)
                {
                    RightSmallVert.transform.position = new Vector3(10.0f, 2.5f, LCamDistance + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                }
                if (RandStimVersion == 1)
                {
                    RightSmallVert.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
                    LeftSmallVert.transform.position = new Vector3(-30.0f, 2.5f, LCamDistance + StimOffset);
                }
            }
        }

        if (MoveDStim == true)
        {
            if (GameMode == GameVersion.AlternateCorridorPanel)
            {
                LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
            }

            if (GameMode == GameVersion.ForcedChoiceTask || GameMode == GameVersion.CuedLowContrastForcedChoice)
            {
                if (RandStimVersion == 0)
                {
                    RightSmallDiag.transform.position = new Vector3(10.0f, 2.5f, LCamDistance + StimOffset);
                    LeftSmallDiag.transform.position = new Vector3(-5.0f, 2.5f, LCamDistance + StimOffset);
                }
                if (RandStimVersion == 1)
                {
                    RightSmallDiag.transform.position = new Vector3(5.0f, 2.5f, LCamDistance + StimOffset);
                    LeftSmallDiag.transform.position = new Vector3(-30.0f, 2.5f, LCamDistance + StimOffset);
                }
            }
        }
    }

    void FixedUpdate()
    {

        //reset position at start
        if (ResetSesh == 1)
        {
            transform.position = new Vector3(0.0f, 1.0f, 0.0f);
            RightEye.transform.position = new Vector3(0.0f, 1.0f, 0.0f);
            StimDistance = 0;
            RandReceived = false;
            LastPosition = 0; 
            RelativePosition = 0;
            StimTrialCount = 0;

        }
    }

    // receive thread 
    private void ReceiveData()
    {
        print("allocating client");
        IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, ReceivePort);
        client = new UdpClient(ReceivePort);
        client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (receiveRunning)
        {
            try
            {
                data = client.Receive(ref anyIP); //byte[] data
                text = Encoding.UTF8.GetString(data);
                // latest UDPpacket
                lastReceivedUDPPacket = text;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    private void SendData()
    {
        print("sending client");
        IPEndPoint SendtoIP = new IPEndPoint(IPAddress.Parse(SendIP), SendPort);
        SendClient = new UdpClient(SendPort);
        SendClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        while (sendRunning)
        {
            try
            {
                DataToSend = Encoding.UTF8.GetBytes(TextToSend);
                SendClient.Send(DataToSend, DataToSend.Length, SendtoIP);
                lastSentUDPPacket = TextToSend;
            }
            catch (Exception er)
            {
                print(er.ToString());
            }
        }
    }

    public string getLatestUDPPacket()
    {
        return lastReceivedUDPPacket;
        return lastSentUDPPacket;
    }

    void OnApplicationQuit()
    {
        // stop listening thread
        receiveRunning = false;
        sendRunning = false;
        client.Close();
        SendClient.Close();

        // wait for listening thread to terminate (max. 500ms)		
        receiveThread.Join(500);
        sendThread.Join(500);
    }

}